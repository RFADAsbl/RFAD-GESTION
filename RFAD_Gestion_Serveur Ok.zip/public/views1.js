'use strict';
(function () {
const RF = window.RF, h = RF.h, api = RF.api;
const DEPT_ORDER = ['ADM', 'RH', 'FIN', 'CPT', 'LOG', 'SEC'];
// ---------------------------------------------------------------- connexion / inscription
RF.loginView = function (root, mode) {
  mode = mode || 'login';
  const msg = h('div', { class: 'hint hidden', role: 'alert' });
  const show = (t, ok) => { msg.textContent = t; msg.classList.remove('hidden'); msg.style.background = ok ? '#e2f4e0' : '#fff8e1'; };
  let form;
  if (mode === 'login') {
    const u = h('input', { type: 'text', autocomplete: 'username', autocapitalize: 'none', required: true }), p = h('input', { type: 'password', autocomplete: 'current-password', required: true });
    form = h('form', { class: 'grid', onsubmit: RF.guard(async e => { e.preventDefault(); try { const r = await api('POST', '/api/login', { username: u.value, password: p.value }); await RF.boot(); if (r.must_change) RF.forceChange(); } catch (er) { show(er.message); } }) },
      RF.field('Nom d’utilisateur ou e-mail', u), RF.field('Mot de passe', p), h('button', { class: 'btn p', type: 'submit' }, 'Se connecter'),
      h('div', { class: 'row sm' }, h('a', { href: '#/inscription' }, 'Demander un accès'), h('span', { class: 'sp' }), h('a', { href: '#/candidature' }, 'Postuler à une offre')));
  } else {
    const f = n => h('input', { type: 'text', name: n });
    const un = f('username'), nm = f('name'), em = h('input', { type: 'email' }), ph = h('input', { type: 'tel' }), pw = h('input', { type: 'password', autocomplete: 'new-password' }), pw2 = h('input', { type: 'password', autocomplete: 'new-password' });
    const post = f('post'), dep = RF.sel([['', '— Département —'], ...DEPT_ORDER.map(d => [d, ({ ADM: 'Administration', RH: 'Ressources humaines', FIN: 'Finances', CPT: 'Comptabilité', LOG: 'Logistique et achats', SEC: 'Sécurité' })[d]])]); const mm = h('textarea', { rows: 2, placeholder: 'Motif de la demande (facultatif)' });
    form = h('form', { class: 'grid', onsubmit: RF.guard(async e => { e.preventDefault(); if (pw.value !== pw2.value) return show('Les deux mots de passe ne correspondent pas.'); try { const r = await api('POST', '/api/register', { username: un.value, name: nm.value, email: em.value, phone: ph.value, password: pw.value, requested_post: post.value, dept: dep.value, message: mm.value }); show(r.message, true); form.reset(); } catch (er) { show(er.message); } }) },
      RF.field('Nom complet', nm), RF.field('Nom d’utilisateur souhaité', un), h('div', { class: 'grid g2' }, RF.field('Courriel (pour recevoir la décision)', em), RF.field('Téléphone', ph)), RF.field('Poste demandé', post), RF.field('Département', dep),
      RF.field('Mot de passe (10 caractères minimum, lettres et chiffres)', pw), RF.field('Confirmer le mot de passe', pw2), mm, h('button', { class: 'btn p', type: 'submit' }, 'Envoyer la demande'),
      h('div', { class: 'sm mute' }, 'Votre accès, votre rôle et vos tâches seront définis par l’administrateur selon le manuel de procédures.'), h('a', { class: 'sm', href: '#/' }, '← Retour à la connexion'));
  }
  const pwa = h('div', { class: 'pwa hidden', id: 'pwa' }, 'Installer l’application sur cet appareil ', h('button', { class: 'btn s p', id: 'pwabtn' }, 'Installer'));
  RF.clear(root).append(h('div', { class: 'login' }, h('div', { class: 'art' }, h('img', { src: '/img/logo.png', alt: 'RFAD', style: { width: '96px', background: '#fff', borderRadius: '50%', padding: '6px', marginBottom: '18px' } }), h('h1', null, 'RFAD Gestion'), h('p', null, 'Système de gestion intégré de RFAD ASBL : administration, ressources humaines, finances, comptabilité, logistique et sécurité, selon le manuel de procédures.'), h('p', { class: 'sm' }, 'Réseau des Femmes pour l’Aide et le Développement · Beni, Nord-Kivu, RDC')),
    h('div', { class: 'box' }, h('div', { class: 'grid' }, h('div', null, h('h1', null, mode === 'login' ? 'Connexion' : 'Demande d’accès'), h('p', { class: 'mute sm' }, mode === 'login' ? 'Accès réservé au personnel autorisé par l’administrateur.' : 'La demande est transmise à l’administrateur (rfad.rdc@gmail.com), qui valide chaque accès.')), msg, form, pwa))));
  if (RF.deferredPrompt) { pwa.classList.remove('hidden'); RF.q('#pwabtn').onclick = () => RF.deferredPrompt.prompt(); }
};
RF.forceChange = function () {
  const cur = h('input', { type: 'password' }), n1 = h('input', { type: 'password' }), n2 = h('input', { type: 'password' });
  RF.modal('Changez votre mot de passe', h('div', { class: 'grid' }, h('p', null, 'Pour votre sécurité, choisissez un nouveau mot de passe personnel (10 caractères minimum, lettres et chiffres).'), RF.field('Mot de passe actuel', cur), RF.field('Nouveau mot de passe', n1), RF.field('Confirmer', n2)),
    [{ label: 'Enregistrer', cls: 'p', fn: async c => { if (n1.value !== n2.value) { RF.toast('Les mots de passe ne correspondent pas', true); return false; } await api('POST', '/api/password', { current: cur.value, password: n1.value }); c(); RF.toast('Mot de passe modifié'); await RF.boot(); } }], { sticky: true });
};
// ---------------------------------------------------------------- tableau de bord
RF.views.dashboard = async function (el) {
  const d = await api('GET', '/api/dashboard'); const u = RF.me.user; const by = d.by_status; const tot = Object.values(by).reduce((a, b) => a + b, 0);
  const stat = (n, l, c) => h('div', { class: 'card stat', style: { '--dc': c } }, h('b', null, n), h('span', null, l));
  el.append(h('div', { class: 'row mb' }, h('div', null, h('h1', null, 'Bonjour, ' + u.name.split(' ')[0]), h('div', { class: 'mute' }, RF.me.role_label + (u.post ? ' · ' + u.post : '') + (u.dept ? ' · ' + RF.me.depts[u.dept] : ''))), h('span', { class: 'sp' }), h('a', { class: 'btn p', href: '#/nouveau' }, '＋ Nouveau document')));
  el.append(h('div', { class: 'grid g4' }, stat(RF.me.counts.todo, 'À valider par moi', '#C2397F'), stat(by.review || 0, 'En cours de validation', '#E8A317'), stat(by.approved || 0, 'Validés', '#4E9A2F'), stat(RF.me.counts.tasks, 'Mes tâches ouvertes', '#2F5DA8')));
  if (d.responsibilities) el.append(h('div', { class: 'card mt' }, h('h2', null, 'Mes responsabilités'), h('p', { style: { whiteSpace: 'pre-wrap', margin: '6px 0 0' } }, d.responsibilities)));
  const tbl = (rows, empty) => rows.length ? h('div', { class: 'tw' }, h('table', { class: 't' }, h('thead', null, h('tr', null, ['Référence', 'Objet', 'Statut', 'Mis à jour'].map(x => h('th', null, x)))), h('tbody', null, rows.map(r => h('tr', { style: { cursor: 'pointer' }, onclick: () => location.hash = '#/doc/' + r.id }, h('td', null, r.ref), h('td', null, r.title || r.tool, h('div', { class: 'sm mute' }, r.tool)), h('td', null, RF.chip(r.status)), h('td', { class: 'sm' }, RF.fmtDate(r.updated_at))))))) : h('div', { class: 'empty' }, empty);
  el.append(h('div', { class: 'grid g2 mt' }, h('div', { class: 'card' }, h('div', { class: 'row mb' }, h('h2', null, 'À valider'), h('span', { class: 'sp' }), h('a', { href: '#/validations', class: 'sm' }, 'Tout voir')), tbl(d.todo, 'Aucun document en attente de votre signature.')),
    h('div', { class: 'card' }, h('div', { class: 'row mb' }, h('h2', null, 'Mes documents récents'), h('span', { class: 'sp' }), h('a', { href: '#/docs', class: 'sm' }, 'Tout voir')), tbl(d.mine, 'Vous n’avez encore créé aucun document.'))));
  el.append(h('div', { class: 'grid g2 mt' }, h('div', { class: 'card' }, h('h2', { class: 'mb' }, 'Mes tâches'), d.tasks.length ? d.tasks.map(t => h('div', { class: 'row', style: { padding: '6px 0', borderBottom: '1px solid var(--line)' } }, h('div', null, h('b', null, t.title), h('div', { class: 'sm mute' }, (t.due ? 'Échéance ' + t.due + ' · ' : '') + 'de ' + (t.cname || '—') + (t.procedure_ref ? ' · ' + t.procedure_ref : ''))), h('span', { class: 'sp' }), h('button', { class: 'btn s', onclick: RF.guard(async () => { await api('PUT', '/api/tasks/' + t.id, { status: 'done' }); RF.route(); }) }, '✓ Terminé'))) : h('div', { class: 'empty' }, 'Aucune tâche ouverte.')),
    h('div', { class: 'card' }, h('h2', { class: 'mb' }, 'Validations en retard (> 3 jours)'), d.late.length ? d.late.map(l => h('div', { style: { padding: '6px 0', borderBottom: '1px solid var(--line)', cursor: 'pointer' }, onclick: () => location.hash = '#/doc/' + l.id }, h('b', null, l.ref), ' – ', l.title || '', h('div', { class: 'sm mute' }, l.label + ' · ' + l.assignee))) : h('div', { class: 'empty' }, 'Aucun retard.'))));
  if (RF.me.can_view_all || Object.keys(d.by_dept).length) { const mx = Math.max(1, ...Object.values(d.by_dept)); el.append(h('div', { class: 'card mt' }, h('h2', { class: 'mb' }, 'Documents par département (' + tot + ')'), DEPT_ORDER.map(k => h('div', { class: 'row d-' + k, style: { margin: '6px 0' } }, h('span', { style: { width: '230px', fontSize: '.85rem' } }, RF.me.depts[k]), h('div', { style: { flex: 1, background: '#f3eef8', borderRadius: '6px', height: '16px' } }, h('div', { style: { width: (100 * (d.by_dept[k] || 0) / mx) + '%', background: 'var(--dc)', height: '16px', borderRadius: '6px' } })), h('b', { style: { width: '34px', textAlign: 'right' } }, d.by_dept[k] || 0))))); }
  el.append(h('div', { class: 'pwa mt noprint' }, h('b', null, 'Utiliser sur téléphone ou ordinateur : '), 'ouvrez cette adresse dans le navigateur puis choisissez « Installer l’application » / « Ajouter à l’écran d’accueil ».'));
};
// ---------------------------------------------------------------- catalogue des outils / nouveau document
RF.views.nouveau = async function (el, arg) {
  if (arg) return RF.editor(el, { code: arg });
  const cat = await api('GET', '/api/catalogue'); let dept = '', qtxt = '', only = true;
  const out = h('div'); const draw = () => { RF.clear(out); const rows = cat.filter(t => (!dept || t.dept === dept) && (!only || t.allowed) && (!qtxt || (t.title + ' ' + t.code).toLowerCase().includes(qtxt.toLowerCase())));
    out.append(h('div', { class: 'mute sm mb' }, rows.length + ' outil(s)')); out.append(h('div', { class: 'grid g3' }, rows.map(t => h('div', { class: 'card toolcard d-' + t.dept + (t.allowed ? '' : ' no'), onclick: () => t.allowed && (location.hash = '#/nouveau/' + t.code) }, h('div', { class: 'tc' }, t.code), h('b', null, t.title), h('div', { class: 'sm mute' }, t.user + ' · ' + t.freq), h('div', { class: 'row' }, RF.deptTag(t.dept), h('span', { class: 'sp' }), h('span', { class: 'chip' }, t.support), t.allowed ? h('button', { class: 'btn s noprint', onclick: e => { e.stopPropagation(); location.hash = '#/vierge/' + t.code; } }, '🖨 Vierge') : h('span', { class: 'chip' }, '🔒')))))); };
  el.append(h('h1', { class: 'mb' }, 'Outils de gestion'), h('p', { class: 'mute' }, 'Choisissez l’outil prévu par le manuel de procédures. Les outils affichés dépendent de votre poste.'));
  el.append(h('div', { class: 'row mb' }, RF.sel([['', 'Tous les départements'], ...DEPT_ORDER.map(d => [d, RF.me.depts[d]])], '', { style: { maxWidth: '320px' }, onchange: e => { dept = e.target.value; draw(); } }), h('input', { type: 'search', placeholder: 'Rechercher un outil ou un code…', style: { maxWidth: '320px' }, oninput: e => { qtxt = e.target.value; draw(); } }), h('label', { class: 'row sm' }, h('input', { type: 'checkbox', checked: true, onchange: e => { only = e.target.checked; draw(); } }), 'Seulement ceux que je peux utiliser')), out); draw();
};
RF.views.vierge = async function (el, code) { // formulaire vierge imprimable
  const form = await api('GET', '/api/forms/' + code); const r = RF.renderForm(form, {}, {});
  el.append(h('div', { class: 'row mb noprint' }, h('a', { class: 'btn', href: '#/nouveau' }, '← Retour'), h('span', { class: 'sp' }), h('button', { class: 'btn p', onclick: () => print() }, '🖨 Imprimer / PDF')), h('div', { class: 'sheet d-' + form.dept }, RF.letterhead(form, null), r.el));
};
// ---------------------------------------------------------------- éditeur de document
RF.editor = async function (el, { code, id }) {
  let doc = null, form, data = {};
  if (id) { const v = await api('GET', '/api/docs/' + id); doc = v.doc; form = v.form; data = doc.data; if (!v.can.edit) { location.hash = '#/doc/' + id; return; } } else form = await api('GET', '/api/forms/' + code);
  const reopen = doc && !['draft', 'rejected'].includes(doc.status); const date = h('input', { type: 'date', value: (data.meta && data.meta.date) || new Date().toISOString().slice(0, 10) });
  const title = h('input', { type: 'text', maxlength: 200, value: doc ? doc.title : '', placeholder: 'Intitulé du document' }), proj = h('input', { type: 'text', maxlength: 120, value: doc ? doc.project : '', placeholder: 'Code projet / bailleur' }), amt = h('input', { type: 'number', min: 0, step: '0.01', value: doc && doc.amount ? doc.amount : '' });
  const doa = h('div', { class: 'sm mute' }); const upd = () => { doa.textContent = Number(amt.value) > 0 ? 'Niveau d’approbation requis (matrice des délégations) : ' + RF.doaFor(amt.value) : 'Sans montant : validation par le circuit standard de l’outil.'; }; amt.oninput = upd; upd();
  const reason = reopen ? h('input', { type: 'text', placeholder: 'Motif de la correction (obligatoire)' }) : null; const r = RF.renderForm(form, data, {});
  const save = RF.guard(async (goto) => { const body = { title: title.value, project: proj.value, amount: Number(amt.value) || 0, data: { ...r.collect(), meta: { date: date.value } }, reason: reason ? reason.value : undefined };
    if (doc) { await api('PUT', '/api/docs/' + doc.id, body); RF.toast('Document enregistré'); location.hash = '#/doc/' + doc.id; } else { body.code = form.code; const x = await api('POST', '/api/docs', body); RF.toast('Brouillon enregistré'); location.hash = '#/doc/' + x.id; } });
  el.append(h('div', { class: 'row mb noprint' }, h('a', { class: 'btn', href: doc ? '#/doc/' + doc.id : '#/nouveau' }, '← Annuler'), h('span', { class: 'sp' }), h('button', { class: 'btn', onclick: () => print() }, '🖨 Imprimer'), h('button', { class: 'btn p', onclick: () => save() }, '💾 Enregistrer')));
  if (reopen) el.append(h('div', { class: 'hint mb' }, 'Ce document a déjà été soumis. Toute correction crée une nouvelle version, conserve l’historique et ', RF.me.user.role === 'ADMIN' ? 'est tracée dans le journal (correction administrative, circuit conservé).' : 'remet le document en brouillon pour une nouvelle validation.'), RF.field('Motif de la correction', reason));
  el.append(h('div', { class: 'card mb noprint' }, h('div', { class: 'grid g4' }, RF.field('Objet / intitulé', title), RF.field('Date du document', date), RF.field('Projet / bailleur', proj), RF.field('Montant concerné (USD)', amt)), doa));
  el.append(h('div', { class: 'sheet d-' + form.dept }, RF.letterhead(form, doc), r.el));
  el.append(h('div', { class: 'row mt noprint' }, h('span', { class: 'sp' }), h('button', { class: 'btn p', onclick: () => save() }, '💾 Enregistrer')));
};
// ---------------------------------------------------------------- liste de documents
RF.views.docs = async function (el, scope) {
  scope = scope || 'mine'; const tabs = [['mine', 'Mes documents'], ['signed', 'Que j’ai signés'], ['dept', RF.me.can_view_all ? 'Tous les documents' : 'Mon département']]; let status = '', dept = '', qtxt = '';
  const out = h('div'); const draw = RF.guard(async () => { const p = new URLSearchParams({ scope: scope === 'all' ? 'dept' : scope }); if (status) p.set('status', status); if (dept) p.set('dept', dept); if (qtxt) p.set('q', qtxt); const rows = await api('GET', '/api/docs?' + p); RF.clear(out).append(rows.length ? h('div', { class: 'card tw' }, h('table', { class: 't' }, h('thead', null, h('tr', null, ['Référence', 'Objet', 'Département', 'Auteur', 'Statut', 'Montant', 'Mis à jour'].map(x => h('th', null, x)))), h('tbody', null, rows.map(r => h('tr', { style: { cursor: 'pointer' }, onclick: () => location.hash = '#/doc/' + r.id }, h('td', null, r.ref), h('td', null, r.title || '—', h('div', { class: 'sm mute' }, r.tool)), h('td', null, RF.deptTag(r.dept)), h('td', null, r.author), h('td', null, RF.chip(r.status)), h('td', null, r.amount ? r.amount.toLocaleString('fr-FR') : ''), h('td', { class: 'sm' }, RF.fmtDate(r.updated_at))))))) : h('div', { class: 'card empty' }, 'Aucun document.')); });
  el.append(h('div', { class: 'row mb' }, h('h1', null, 'Documents'), h('span', { class: 'sp' }), h('a', { class: 'btn p', href: '#/nouveau' }, '＋ Nouveau')), h('div', { class: 'tabs' }, tabs.map(([k, l]) => h('button', { class: scope === k || (scope === 'all' && k === 'dept') ? 'on' : '', onclick: () => location.hash = '#/docs/' + k }, l))),
    h('div', { class: 'row mb' }, RF.sel([['', 'Tous statuts'], ...Object.entries(RF.STATUS)], '', { style: { maxWidth: '200px' }, onchange: e => { status = e.target.value; draw(); } }), RF.sel([['', 'Tous départements'], ...DEPT_ORDER.map(d => [d, RF.me.depts[d]])], '', { style: { maxWidth: '280px' }, onchange: e => { dept = e.target.value; draw(); } }), h('input', { type: 'search', placeholder: 'Rechercher…', style: { maxWidth: '260px' }, oninput: e => { qtxt = e.target.value; clearTimeout(RF._t); RF._t = setTimeout(draw, 300); } })), out); draw();
};
RF.views.validations = async function (el) {
  const rows = await api('GET', '/api/docs?scope=todo');
  el.append(h('h1', { class: 'mb' }, 'Documents à valider'), h('p', { class: 'mute' }, 'Chaque document vous est transmis par son auteur selon le circuit défini dans le manuel de procédures.'), rows.length ? h('div', { class: 'card tw' }, h('table', { class: 't' }, h('thead', null, h('tr', null, ['Référence', 'Objet', 'Auteur', 'Montant', 'Reçu le', ''].map(x => h('th', null, x)))), h('tbody', null, rows.map(r => h('tr', null, h('td', null, r.ref), h('td', null, r.title || '—', h('div', { class: 'sm mute' }, r.tool)), h('td', null, r.author), h('td', null, r.amount ? r.amount.toLocaleString('fr-FR') + ' USD' : ''), h('td', { class: 'sm' }, RF.fmtDate(r.updated_at)), h('td', null, h('a', { class: 'btn s p', href: '#/doc/' + r.id }, 'Examiner et signer'))))))) : h('div', { class: 'card empty' }, '✔ Aucun document en attente.'));
};
// ---------------------------------------------------------------- vue d'un document
RF.views.doc = async function (el, id, sub) {
  if (sub === 'edit') return RF.editor(el, { id });
  const v = await api('GET', '/api/docs/' + id); const { doc, form, author, approvals, attachments, versions, can } = v; const nonauth = approvals.filter(a => a.step > 0); const aSig = approvals.find(a => a.step === 0);
  const r = RF.renderForm(form, doc.data, { readonly: true, hideSigns: true });
  const bar = h('div', { class: 'row mb noprint' }, h('a', { class: 'btn', href: '#/docs' }, '← Documents'), h('span', { class: 'sp' }));
  if (can.edit) bar.append(h('a', { class: 'btn', href: '#/doc/' + id + '/edit' }, '✏️ Modifier'));
  if (can.reopen && !can.edit) bar.append(h('a', { class: 'btn', href: '#/doc/' + id + '/edit' }, '✏️ Corriger'));
  if (can.submit) bar.append(h('button', { class: 'btn g', onclick: () => RF.submitDialog(doc) }, '➤ Soumettre pour validation'));
  if (can.decide) bar.append(h('button', { class: 'btn p', onclick: () => RF.decideDialog(doc, can.decide) }, '✍ Valider / retourner'));
  if (doc.status === 'approved' && (can.admin || doc.author_id === RF.me.user.id)) bar.append(h('button', { class: 'btn', onclick: RF.guard(async () => { await api('POST', '/api/docs/' + id + '/archive'); RF.route(); }) }, '🗄 Archiver'));
  const exp = h('select', { class: 'btn', style: { width: 'auto' }, onchange: e => { if (e.target.value) { RF.download('/api/docs/' + id + '/export?fmt=' + e.target.value); e.target.value = ''; } } }, h('option', { value: '' }, '⬇ Exporter…'), h('option', { value: 'docx' }, 'Word (.docx)'), h('option', { value: 'xlsx' }, 'Excel (.xlsx)'), h('option', { value: 'pptx' }, 'PowerPoint (.pptx)'), h('option', { value: 'json' }, 'Données (.json)'));
  bar.append(exp, h('button', { class: 'btn', onclick: () => print() }, '🖨 Imprimer / PDF'));
  if (can.delete) bar.append(h('button', { class: 'btn d', onclick: RF.guard(async () => { if (await RF.confirm('Supprimer ce brouillon ?', 'Supprimer')) { await api('DELETE', '/api/docs/' + id); location.hash = '#/docs'; } }) }, 'Supprimer'));
  el.append(bar);
  const head = h('div', { class: 'row mb' }, h('h1', null, doc.title || form.title), RF.chip(doc.status), RF.deptTag(doc.dept), h('span', { class: 'mute sm' }, doc.ref + ' · v' + doc.version));
  el.append(head, h('div', { class: 'sm mute mb' }, 'Établi par ' + author.name + (doc.project ? ' · Projet : ' + doc.project : '') + (doc.amount ? ' · Montant : ' + doc.amount.toLocaleString('fr-FR') + ' USD' : '') + ' · Créé le ' + RF.fmtDate(doc.created_at)));
  const rejected = approvals.find(a => a.status === 'rejected'); if (doc.status === 'rejected' && rejected) el.append(h('div', { class: 'hint mb', style: { background: '#fde4e4', borderColor: '#f0b0ac' } }, '↩ Retourné par ' + (rejected.signer_name || '') + ' : ' + (rejected.comment || '')));
  // feuille imprimable
  const sheet = h('div', { class: 'sheet d-' + form.dept }, RF.letterhead(form, doc), (doc.title ? h('div', { style: { fontWeight: 700, color: 'var(--dc)', margin: '8px 0' } }, 'Objet : ' + doc.title) : null), r.el);
  const signs = h('div', { class: 'signs' });
  const sg = (title, name, when, sig, state) => h('div', { class: 'sg ' + (state || '') }, h('b', null, title), sig ? h('img', { src: sig, alt: 'signature' }) : h('span', { class: 'mute' }, state === 'pend' ? 'En attente de signature' : state === 'rej' ? 'Retourné' : 'Non signé'), h('div', null, name || ''), h('div', { class: 'mute' }, when || ''));
  signs.append(sg('Établi par (auteur)', author.name, aSig ? RF.fmtDate(aSig.signed_at) : '', aSig && aSig.signature, aSig ? '' : ''));
  nonauth.forEach(a => signs.append(sg(a.label || a.role_label, a.signer_name || a.assignee_name, a.signed_at ? RF.fmtDate(a.signed_at) + (a.sig_hash ? ' · ' + a.sig_hash.slice(0, 10) : '') : '', a.signature, a.status === 'pending' ? 'pend' : a.status === 'rejected' ? 'rej' : '')));
  const ext = form.blocks.filter(b => b.type === 'sign').flatMap(b => b.roles); const extRoles = ext.filter(l => /pris acte|reçu|acquit|évalué|fournisseur|représentant|témoin|bénéficiaire|déposant|délégataire|personne concernée|titulaire|destinataire|signature de l’agent|agent sortant/i.test(l));
  extRoles.forEach(l => signs.append(h('div', { class: 'sg' }, h('b', null, l), h('span', { class: 'mute' }, 'Signature manuscrite sur la version imprimée'))));
  sheet.append(h('div', { style: { fontWeight: 700, color: 'var(--dc)', marginTop: '14px' } }, 'Circuit de validation et signatures électroniques'), signs, h('div', { class: 'note', style: { marginTop: '8px' } }, 'Chaque signature électronique est liée au contenu du document (empreinte SHA-256) et à l’identité du signataire.'));
  el.append(sheet);
  // pièces jointes
  const upl = h('input', { type: 'file', class: 'hidden', multiple: true, onchange: RF.guard(async e => { for (const f of e.target.files) { await api('POST', '/api/docs/' + id + '/attach', { name: f.name, mime: f.type, data: await RF.fileToB64(f) }); } RF.toast('Pièce(s) jointe(s) ajoutée(s)'); RF.route(); }) });
  const canAtt = (doc.author_id === RF.me.user.id && ['draft', 'rejected'].includes(doc.status)) || can.admin;
  el.append(h('div', { class: 'grid g2 mt noprint' }, h('div', { class: 'card' }, h('div', { class: 'row mb' }, h('h2', null, 'Pièces jointes (Word, Excel, PowerPoint, PDF, images…)'), h('span', { class: 'sp' }), canAtt ? h('button', { class: 'btn s', onclick: () => upl.click() }, '＋ Ajouter') : null, upl),
    attachments.length ? attachments.map(a => h('div', { class: 'row', style: { padding: '6px 0', borderBottom: '1px solid var(--line)' } }, h('a', { href: '/api/files/' + a.id }, a.name), h('span', { class: 'mute sm' }, Math.ceil(a.size / 1024) + ' Ko'), h('span', { class: 'sp' }), canAtt ? h('button', { class: 'btn s', onclick: RF.guard(async () => { await api('DELETE', '/api/files/' + a.id); RF.route(); }) }, '✕') : null)) : h('div', { class: 'mute sm' }, 'Aucune pièce jointe.')),
    h('div', { class: 'card' }, h('h2', { class: 'mb' }, 'Historique et versions'), h('div', { class: 'tl' }, versions.map(x => h('div', { class: 'ev' }, h('b', null, 'v' + x.version), ' · ', RF.fmtDate(x.at), h('div', { class: 'sm mute' }, (x.by_name || '') + (x.reason ? ' – ' + x.reason : '')))), versions.length ? null : h('div', { class: 'mute sm' }, 'Version initiale en cours de rédaction.')))));
};
// ---- dialogues de soumission et de décision
RF.submitDialog = async function (doc) {
  const ch = await api('POST', '/api/chain', { code: doc.code, amount: doc.amount }); const sels = {}; const body = h('div', { class: 'grid' });
  body.append(h('p', null, 'Choisissez, pour chaque étape du circuit prévu par le manuel, la personne à qui le document sera transmis pour validation.'));
  if (doc.amount > 0) body.append(h('div', { class: 'hint' }, 'Montant ' + doc.amount.toLocaleString('fr-FR') + ' USD → niveau requis : ' + RF.doaFor(doc.amount)));
  ch.steps.forEach(s => { const s2 = h('select', null, h('option', { value: '' }, s.candidates.length ? '— Choisir —' : 'Aucun utilisateur avec ce rôle'), s.candidates.map(c => h('option', { value: c.id }, c.name + (c.post ? ' – ' + c.post : '')))); if (s.candidates.length === 1) s2.value = s.candidates[0].id; sels[s.step] = s2; body.append(RF.field(`Étape ${s.step} : ${s.label} (${s.role_label})`, s2)); });
  if (ch.ext.length) body.append(h('div', { class: 'sm mute' }, 'Signatures manuscrites sur la version imprimée : ' + ch.ext.join(', ')));
  const pad = RF.sigpad(RF.me.user.name), pw = h('input', { type: 'password', autocomplete: 'current-password' }); body.append(h('div', null, h('b', null, 'Votre signature'), pad.el), RF.field('Mot de passe (confirmation de la signature)', pw));
  RF.modal('Soumettre pour validation', body, [{ label: 'Annuler', fn: c => c() }, { label: 'Signer et soumettre', cls: 'p', fn: async c => { const approvers = {}; for (const s of ch.steps) approvers[s.step] = sels[s.step].value; const sig = pad.get(); await api('POST', '/api/docs/' + doc.id + '/submit', { approvers, signature: sig, password: pw.value }); c(); RF.toast('Document transmis pour validation'); RF.route(); } }]);
};
RF.decideDialog = function (doc, apId) {
  let act = 'approve'; const pad = RF.sigpad(RF.me.user.name), pw = h('input', { type: 'password', autocomplete: 'current-password' }), cm = h('textarea', { rows: 3, placeholder: 'Commentaire (obligatoire en cas de retour)' });
  const sigbox = h('div', null, h('b', null, 'Votre signature'), pad.el);
  const mode = RF.sel([['approve', '✔ Valider et signer'], ['reject', '↩ Retourner pour correction']], 'approve', { onchange: e => { act = e.target.value; sigbox.classList.toggle('hidden', act === 'reject'); } });
  RF.modal('Décision sur ' + doc.ref, h('div', { class: 'grid' }, h('p', null, doc.title || ''), RF.field('Décision', mode), cm, sigbox, RF.field('Mot de passe (confirmation)', pw)), [{ label: 'Annuler', fn: c => c() }, { label: 'Enregistrer ma décision', cls: 'p', fn: async c => { const body = { action: act, comment: cm.value, password: pw.value }; if (act === 'approve') body.signature = pad.get(); await api('POST', '/api/docs/' + doc.id + '/decide', body); c(); RF.toast(act === 'approve' ? 'Document validé et signé' : 'Document retourné à l’auteur'); RF.route(); } }]);
};
})();
