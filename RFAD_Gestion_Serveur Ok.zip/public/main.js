'use strict';
(function () {
const RF = window.RF, h = RF.h, api = RF.api;
const NAV = [
  ['', '🏠', 'Tableau de bord', null], ['nouveau', '＋', 'Nouveau document', null], ['validations', '✍', 'À valider', 'todo'], ['docs', '🗂', 'Documents', null], ['taches', '✅', 'Tâches', 'tasks'],
  ['sec', 'Référentiel'], ['procedures', '📖', 'Manuel de procédures', null], ['modeles', '📄', 'Modèles Word / Excel / PPT', null],
  ['sec', 'Modules'], ['enquetes', '📝', 'Enquêtes', null], ['recrutement', '👥', 'Recrutement', null, ['ADMIN', 'DE', 'COORD', 'RH']], ['rapports', '📊', 'Rapports', null],
  ['sec', 'Compte'], ['admin', '⚙️', 'Administration', 'pending_users', ['ADMIN', 'CC']], ['profil', '👤', 'Mon profil', null]];
const TITLES = { '': 'Tableau de bord', nouveau: 'Outils de gestion', validations: 'À valider', docs: 'Documents', taches: 'Tâches', procedures: 'Manuel de procédures', modeles: 'Modèles', enquetes: 'Enquêtes', recrutement: 'Recrutement', rapports: 'Rapports', admin: 'Administration', profil: 'Mon profil', doc: 'Document', vierge: 'Formulaire vierge', enquete: 'Enquête' };
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); RF.deferredPrompt = e; const b = RF.q('#pwa'); if (b) { b.classList.remove('hidden'); RF.q('#pwabtn').onclick = () => e.prompt(); } });
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
RF.boot = async function () {
  try { RF.me = await api('GET', '/api/me'); } catch (e) { RF.me = null; }
  RF.route();
};
RF.route = async function () {
  const root = RF.q('#app'); const parts = (location.hash.replace(/^#\/?/, '') || '').split('/'); const [name, a, b] = parts.map(decodeURIComponent);
  if (RF.publicViews[name] && (name === 'e' || name === 'candidature')) return RF.publicViews[name](root, a);
  if (!RF.me) { if (name === 'inscription') return RF.loginView(root, 'register'); return RF.loginView(root, 'login'); }
  if (name === 'inscription') { location.hash = '#/'; return; }
  document.title = 'RFAD Gestion – ' + (TITLES[name] || '');
  const u = RF.me.user; const nav = h('nav', { class: 'nav' });
  NAV.forEach(n => { if (n[0] === 'sec') return nav.append(h('div', { class: 'sec' }, n[1])); const [k, ic, lb, cnt, roles] = n; if (roles && !roles.includes(u.role)) return; const c = cnt ? RF.me.counts[cnt] : 0; nav.append(h('a', { href: '#/' + k, class: (name === k || (name === 'doc' && k === 'docs') || (name === 'vierge' && k === 'nouveau') || (name === 'enquete' && k === 'enquetes')) ? 'on' : '', onclick: () => RF.q('.side') && RF.q('.side').classList.remove('open') }, h('i', null, ic), lb, c ? h('span', { class: 'badge' }, c) : null)); });
  const bell = h('div', { class: 'rel' }); const bb = h('button', { class: 'btn s', 'aria-label': 'Notifications', onclick: RF.guard(async () => { const pop = RF.q('.pop', bell); if (pop) return pop.remove(); const ns = await api('GET', '/api/notifications'); const p = h('div', { class: 'pop' }, ns.length ? ns.map(x => h('div', { class: 'it' + (x.read ? '' : ' un'), onclick: () => { location.hash = x.link || '#/'; p.remove(); } }, x.text, h('div', { class: 'sm mute' }, RF.fmtDate(x.at)))) : h('div', { class: 'empty' }, 'Aucune notification')); bell.append(p); if (RF.me.counts.notif) { await api('POST', '/api/notifications/read'); RF.me.counts.notif = 0; bb.textContent = '🔔'; } }) }, '🔔' + (RF.me.counts.notif ? ' ' + RF.me.counts.notif : '')); bell.append(bb);
  const side = h('aside', { class: 'side' }, h('div', { class: 'brand' }, h('img', { src: '/img/logo.png', alt: 'RFAD' }), h('div', null, h('b', null, 'RFAD Gestion'), h('small', null, 'Beni · Nord-Kivu · RDC'))), nav, h('div', { class: 'sp' }), h('div', { style: { padding: '10px', fontSize: '.8rem', opacity: .85 } }, u.name, h('br'), RF.me.role_label), h('a', { href: '#', style: { color: '#fff', padding: '8px 12px', textDecoration: 'none', fontSize: '.88rem' }, onclick: RF.guard(async e => { e.preventDefault(); await api('POST', '/api/logout'); RF.me = null; location.hash = '#/'; RF.route(); }) }, '⏻ Déconnexion'));
  const content = h('div', { class: 'content', id: 'content' }); const main = h('div', { class: 'main' }, h('div', { class: 'top' }, h('button', { class: 'btn s burger', 'aria-label': 'Menu', onclick: () => side.classList.toggle('open') }, '☰'), h('div', { class: 't' }, TITLES[name] || 'RFAD Gestion'), bell), content);
  RF.clear(root).append(h('div', { class: 'shell' }, side, main)); window.scrollTo(0, 0);
  const view = RF.views[name === '' ? 'dashboard' : name]; if (!view) return content.append(h('div', { class: 'card empty' }, 'Page introuvable.'));
  try { await view(content, a, b); } catch (e) { content.append(h('div', { class: 'card empty' }, '⚠ ' + e.message)); }
  RF._ver = (RF._ver || 0) + 1;
  if (RF.me.user.must_change) RF.forceChange();
};
window.addEventListener('hashchange', () => RF.route());
setInterval(async () => { if (!RF.me || document.hidden) return; try { const m = await api('GET', '/api/me'); if (m.counts.notif > RF.me.counts.notif) RF.toast('🔔 Nouvelle notification'); RF.me.counts = m.counts; const b = document.querySelector('.badge'); } catch (e) {} }, 60000);
RF.boot();
})();
