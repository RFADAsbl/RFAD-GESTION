'use strict';
(function () {
const RF = window.RF = { me: null, views: {}, publicViews: {} };
// ---- DOM helper (aucun innerHTML : tout est inséré via textContent => pas de XSS)
RF.h = function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v; else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else if (k === 'value') el.value = v; else if (k === 'checked') el.checked = !!v;
    else if (v === true) el.setAttribute(k, ''); else el.setAttribute(k, v);
  }
  const add = k => { if (k == null || k === false) return; if (Array.isArray(k)) return k.forEach(add); el.append(k.nodeType ? k : document.createTextNode(String(k))); };
  kids.forEach(add); return el;
};
const h = RF.h;
RF.q = (s, r) => (r || document).querySelector(s);
RF.clear = el => { while (el.firstChild) el.removeChild(el.firstChild); return el; };
RF.fmtDate = t => t ? new Date(t).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) : '';
RF.fmtD = t => t ? new Date(t).toLocaleDateString('fr-FR') : '';
RF.STATUS = { draft: 'Brouillon', review: 'En validation', approved: 'Validé', rejected: 'Retourné', archived: 'Archivé' };
RF.chip = (s, label) => h('span', { class: 'chip ' + s }, label || RF.STATUS[s] || s);
RF.deptTag = d => h('span', { class: 'dept d-' + d }, (RF.me && RF.me.depts[d]) || d);
RF.toast = (m, err) => { const t = h('div', { class: 'toast' + (err ? ' err' : '') }, m); RF.q('#toast').append(t); setTimeout(() => t.remove(), err ? 6000 : 3200); };
RF.api = async function (method, url, body) {
  const o = { method, headers: { 'X-RFAD': '1' }, credentials: 'same-origin' };
  if (body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
  let r; try { r = await fetch(url, o); } catch (e) { throw new Error('Serveur injoignable. Vérifiez la connexion.'); }
  let d = null; try { d = await r.json(); } catch (e) {}
  if (!r.ok) { const err = new Error((d && d.error) || ('Erreur ' + r.status)); err.status = r.status; if (r.status === 401 && RF.me) { RF.me = null; RF.boot(); } throw err; }
  return d;
};
RF.guard = fn => async (...a) => { try { return await fn(...a); } catch (e) { RF.toast(e.message, true); } };
RF.modal = function (title, body, buttons, opts) {
  const ov = h('div', { class: 'ov' }); const close = () => ov.remove();
  const foot = h('footer', null, (buttons || []).map(b => h('button', { class: 'btn ' + (b.cls || ''), onclick: async ev => { ev.target.disabled = true; try { const r = await b.fn(close); if (r === false) ev.target.disabled = false; } catch (e) { RF.toast(e.message, true); ev.target.disabled = false; } } }, b.label)));
  const m = h('div', { class: 'md', style: opts && opts.w ? { maxWidth: opts.w } : null }, h('header', null, h('h2', null, title), h('button', { class: 'btn s', onclick: close }, '✕')), h('div', { class: 'bd' }, body), buttons && buttons.length ? foot : null);
  ov.append(m); ov.addEventListener('mousedown', e => { if (e.target === ov && !(opts && opts.sticky)) close(); }); document.body.append(ov); return { close, el: m };
};
RF.confirm = (msg, yes = 'Confirmer') => new Promise(res => { RF.modal('Confirmation', h('p', null, msg), [{ label: 'Annuler', fn: c => { c(); res(false); } }, { label: yes, cls: 'p', fn: c => { c(); res(true); } }]); });
RF.prompt = (label, ph) => new Promise(res => { const i = h('textarea', { rows: 3, placeholder: ph || '' }); RF.modal(label, i, [{ label: 'Annuler', fn: c => { c(); res(null); } }, { label: 'Valider', cls: 'p', fn: c => { if (!i.value.trim()) { RF.toast('Saisie obligatoire', true); return false; } c(); res(i.value.trim()); } }]); setTimeout(() => i.focus(), 50); });
RF.field = (label, input) => h('label', { class: 'f' }, label, input);
RF.sel = (opts, val, attrs) => { const s = h('select', attrs); opts.forEach(o => { const [v, l] = Array.isArray(o) ? o : [o, o]; s.append(h('option', { value: v }, l)); }); if (val != null) s.value = val; return s; };
RF.download = (url) => { const a = h('a', { href: url }); document.body.append(a); a.click(); a.remove(); };
RF.fileToB64 = f => new Promise((res, rej) => { if (f.size > 8 * 1024 * 1024) return rej(new Error('Fichier trop volumineux (8 Mo max).')); const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error('Lecture impossible')); r.readAsDataURL(f); });

// ---- pavé de signature (dessin tactile / souris, ou signature générée à partir du nom)
RF.sigpad = function (name) {
  const c = h('canvas', { class: 'sigpad', width: 600, height: 150 }); const ctx = c.getContext('2d'); let draw = false, dirty = false;
  const pos = e => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height]; };
  ctx.lineWidth = 2.6; ctx.lineCap = 'round'; ctx.strokeStyle = '#1B1F4B';
  c.addEventListener('pointerdown', e => { draw = true; dirty = true; c.setPointerCapture(e.pointerId); const [x, y] = pos(e); ctx.beginPath(); ctx.moveTo(x, y); e.preventDefault(); });
  c.addEventListener('pointermove', e => { if (!draw) return; const [x, y] = pos(e); ctx.lineTo(x, y); ctx.stroke(); });
  ['pointerup', 'pointercancel'].forEach(t => c.addEventListener(t, () => { draw = false; }));
  const clear = () => { ctx.clearRect(0, 0, c.width, c.height); dirty = false; };
  const typed = () => { clear(); ctx.font = 'italic 54px "Segoe Script","Brush Script MT",cursive'; ctx.fillStyle = '#1B1F4B'; ctx.textBaseline = 'middle'; ctx.fillText(name, 18, 78, 560); dirty = true; };
  const el = h('div', null, c, h('div', { class: 'row mt' }, h('button', { class: 'btn s', type: 'button', onclick: clear }, 'Effacer'), h('button', { class: 'btn s', type: 'button', onclick: typed }, 'Générer à partir de mon nom'), h('span', { class: 'mute sm' }, 'Dessinez votre signature au doigt ou à la souris')));
  return { el, get: () => { if (!dirty) throw new Error('Veuillez signer (dessin ou signature générée).'); const o = document.createElement('canvas'); o.width = 300; o.height = 75; o.getContext('2d').drawImage(c, 0, 0, 300, 75); return o.toDataURL('image/png'); } };
};

// ---- rendu et collecte des formulaires du manuel
// block data : fields {values[]} | text {value} | grid {rows[][]} | check {answers[], obs[]}
RF.renderForm = function (form, data, opts) {
  opts = opts || {}; const ro = !!opts.readonly; data = data || {}; const bl = data.blocks || []; const collectors = [];
  const root = h('div', null);
  form.blocks.forEach((b, i) => {
    const d = bl[i] || {}; const blk = h('div', { class: 'blk' }); root.append(blk);
    if (b.type === 'fields') {
      const vals = []; const g = h('div', { class: 'flds' });
      b.items.forEach((it, j) => { const v = (d.values && d.values[j]) || ''; let inp; if (ro) inp = h('div', { class: 'v ro' }, v); else { inp = h('input', { type: 'text', value: v, maxlength: 300, 'aria-label': it.label }); vals.push(inp); }
        g.append(h('div', { class: 'fl' + (it.wide ? ' w' : '') }, h('span', null, it.label), ro ? inp : h('div', { class: 'v' }, inp))); if (ro) vals.push({ value: v }); });
      blk.append(g); collectors.push(() => ({ values: vals.map(x => x.value) }));
    } else if (b.type === 'text') {
      const ta = h('textarea', { rows: Math.max(2, b.lines || 3), maxlength: 6000 }, ''); ta.value = d.value || '';
      blk.append(h('div', { class: 'tb' }, h('div', { class: 'th' }, b.label), ro ? h('div', { class: 'ro' }, d.value || '') : ta)); collectors.push(() => ({ value: ta.value }));
    } else if (b.type === 'grid') {
      const n = Math.max(b.rows || 3, (d.rows || []).length); const tb = h('tbody'); const rows = [];
      const addRow = (vals, ph) => { const inputs = b.headers.map((hd, j) => { const v = (vals && vals[j]) || ''; if (ro) return h('td', { class: 'ro' }, v); const x = h('input', { type: 'text', value: v, maxlength: 300, placeholder: ph ? ph[j] || '' : '', 'aria-label': hd }); return x; }); rows.push(inputs); tb.append(h('tr', null, inputs.map(x => x.tagName === 'TD' ? x : h('td', null, x)))); };
      const shown = ro ? (d.rows || []).filter(r => r.some(c => String(c || '').trim())) : null;
      if (ro) { (shown.length ? shown : [[]]).forEach(r => addRow(r)); } else for (let k = 0; k < n; k++) addRow((d.rows || [])[k], k === 0 ? b.example : null);
      blk.append(h('div', { class: 'tw' }, h('table', { class: 'gt' }, h('thead', null, h('tr', null, b.headers.map(x => h('th', null, x)))), tb)));
      if (!ro) blk.append(h('button', { class: 'btn s noprint', type: 'button', style: { marginTop: '6px' }, onclick: () => addRow([]) }, '+ Ajouter une ligne'));
      collectors.push(() => ({ rows: rows.map(r => r.map(x => x.tagName === 'TD' ? x.textContent : x.value)) }));
    } else if (b.type === 'check') {
      const ans = (d.answers || []).slice(); const obs = []; const radios = []; const nm = 'c' + Math.random().toString(36).slice(2, 7) + i;
      const tb = h('tbody');
      b.items.forEach((it, j) => { const tds = [h('td', null, it)]; const rs = b.cols.map((cl, k) => { const r = h('input', { type: 'radio', name: nm + j, checked: ans[j] === k, disabled: ro, 'aria-label': cl }); return r; }); radios.push(rs); rs.forEach(r => tds.push(h('td', { class: 'c' }, r)));
        const o = ro ? h('td', { class: 'ro' }, (d.obs && d.obs[j]) || '') : h('td', null, (() => { const x = h('input', { type: 'text', maxlength: 200, value: (d.obs && d.obs[j]) || '' }); obs.push(x); return x; })()); if (ro) obs.push({ value: (d.obs && d.obs[j]) || '' }); tds.push(o); tb.append(h('tr', null, tds)); });
      blk.append(h('div', { class: 'tw' }, h('table', { class: 'gt ct' }, h('thead', null, h('tr', null, h('th', null, 'Point de contrôle'), b.cols.map(x => h('th', null, x)), h('th', null, 'Observation'))), tb)));
      collectors.push(() => ({ answers: radios.map(rs => rs.findIndex(r => r.checked)), obs: obs.map(x => x.value) }));
    } else if (b.type === 'sign') {
      if (!opts.hideSigns) blk.append(h('div', { class: 'signs' }, b.roles.map(r => h('div', { class: 'sg' }, h('b', null, r), h('span', { class: 'mute' }, 'Nom, date et signature :'))))); collectors.push(() => ({}));
    } else { blk.append(h('div', { class: 'note' }, b.text)); collectors.push(() => ({})); }
  });
  return { el: root, collect: () => ({ blocks: collectors.map(f => f()) }) };
};
// en-tête papier à en-tête RFAD
RF.letterhead = (form, doc) => h('div', null, h('img', { class: 'ec', src: '/img/eclat_' + ({ ADM: 'purple', RH: 'navy', FIN: 'gold', CPT: 'blue', LOG: 'green', SEC: 'pink' }[form.dept] || 'purple') + '.png', alt: '' }), h('img', { class: 'wm', src: '/img/logo.png', alt: '' }),
  h('div', { class: 'lh' }, h('img', { src: '/img/logo.png', alt: 'RFAD' }), h('div', null, h('b', null, 'RFAD ASBL – Réseau des Femmes pour l’Aide et le Développement'), h('small', null, 'Beni, Nord-Kivu, République Démocratique du Congo · Manuel de procédures de gestion'))),
  h('div', { class: 'fh' }, h('div', { class: 'c' }, form.code), h('div', { class: 'ti' }, form.title, form.sub ? h('div', { style: { fontWeight: 400, fontSize: '.8rem' } }, form.sub) : null), h('div', { class: 'o' }, doc ? doc.ref : 'RFAD ASBL', h('br'), doc ? RF.STATUS[doc.status] : 'Beni · RDC')));
RF.doaFor = (amount) => { const p = RF.me.params.doa; const a = Number(amount) || 0; for (const l of p) if (l.max == null || a <= l.max) return l.label; return ''; };
})();
