#!/bin/bash
# Lance un serveur de test isolé puis le test de bout en bout
cd "$(dirname "$0")/.."
rm -rf /tmp/rfad_t1
RFAD_DATA=/tmp/rfad_t1 RFAD_PORT=8099 RFAD_REG_LIMIT=100 RFAD_LOGIN_LIMIT=500 RFAD_ADMIN_EMAIL='rfad.rdc@gmail.com' RFAD_ADMIN_PASSWORD='Admin-Test-2026x' node server/server.js > /tmp/srv.log 2>&1 &
SP=$!
sleep 2
node test/e2e.js http://localhost:8099 'Admin-Test-2026x'
RC=$?
kill $SP 2>/dev/null
exit $RC
