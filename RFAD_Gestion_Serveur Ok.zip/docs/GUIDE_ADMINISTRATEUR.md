# RFAD Gestion – Guide de l'administrateur

## Compte principal
Le compte principal de gestion est lié à **rfad.rdc@gmail.com** (connexion par l'e-mail ou `admin`). Le mot de passe initial doit être changé à la première connexion. Toutes les autres personnes soumettent une demande d'accès ; chaque demande est notifiée par e-mail à cette adresse (une fois le SMTP configuré) et dans l'application.

## Créer des accès pour le personnel contractuel
*Administration › Utilisateurs › Nouveau* crée un compte (option « envoyer les identifiants par e-mail »). *Importer une liste* crée plusieurs comptes d'un coup (colonnes : Nom ; E-mail ; Rôle ; Département ; Poste). Chaque personne reçoit un mot de passe temporaire et doit le changer à la première connexion.

## Cycle d'un accès
1. La personne demande un accès (« Demander un accès » sur la page de connexion) avec son poste et un mot de passe.
2. **Seul l'administrateur** valide : *Administration › Demandes d'accès › Traiter* → il attribue le **rôle**, le département, le poste, les **responsabilités et tâches** et, si besoin, des outils supplémentaires.
3. Tant que la demande n'est pas validée, la connexion est refusée. L'administrateur peut suspendre ou réinitialiser un compte à tout moment.

## Circuit d'un document (selon le manuel de procédures)
1. L'agent choisit un outil (OUT-xxx) autorisé pour son poste, remplit le formulaire, joint ses pièces et enregistre (brouillon).
2. Il **soumet** : le circuit de validation prévu par le manuel est affiché (visas des responsables et approbation selon la **matrice des délégations** et le montant) ; **il sélectionne la personne** de chaque étape, signe et confirme son mot de passe.
3. Chaque validateur reçoit une notification, examine, puis **valide et signe** ou **retourne avec motif**. Un retour renvoie le document à l'auteur pour correction et nouvelle soumission.
4. Après la dernière signature le document est **Validé** ; il peut être archivé, imprimé (papier à en-tête RFAD) ou exporté en Word, Excel, PowerPoint ou PDF.
5. Toute correction d'un document soumis ou validé exige un **motif**, crée une **nouvelle version** (historique conservé) et relance la validation ; l'administrateur peut corriger en place (tracé au journal).

## Rôles
| Rôle | Outils accessibles | Peut voir | Rôle dans les validations |
|---|---|---|---|
| Administrateur système | 98 sur 98 | Tout + administration | — |
| Présidente du Conseil d’Administration | 17 sur 98 | Tous les documents (lecture) | Approbation > 100 000 USD |
| Trésorière générale | 40 sur 98 | Tous les documents (lecture) | Signataire A ; 2e approbation > 25 000 USD |
| Membre du Conseil d’Administration | 17 sur 98 | Tous les documents (lecture) | — |
| Directeur exécutif | 98 sur 98 | Tous les documents | Approbation 5 001–100 000 USD ; signataire B |
| Coordination générale | 98 sur 98 | Tous les documents | Approbation 501–5 000 USD |
| Commission de contrôle | 17 sur 98 | Tous les documents + journal d’audit | — |
| Responsable administratif | 25 sur 98 | Ses documents + département ADM | Visa administratif |
| Secrétariat | 25 sur 98 | Ses documents + département ADM | — |
| Responsable des ressources humaines | 37 sur 98 | Ses documents + département RH | Visa RH |
| Responsable finances | 32 sur 98 | Ses documents + département FIN | Visa budget / finance |
| Caissier(ère) | 22 sur 98 | Ses documents (+ ceux où il est validateur) | Caisse |
| Comptable | 40 sur 98 | Ses documents + département CPT, FIN | Contrôle comptable |
| Responsable logistique et achats | 35 sur 98 | Ses documents + département LOG | Validation achats |
| Magasinier | 24 sur 98 | Ses documents (+ ceux où il est validateur) | Réception / stocks |
| Chauffeur | 20 sur 98 | Ses documents (+ ceux où il est validateur) | — |
| Focal point sécurité | 29 sur 98 | Ses documents + département SEC | Visa sécurité |
| Point focal PSEAH / protection | 19 sur 98 | Ses documents (+ ceux où il est validateur) | Protection / PSEAH |
| Chef de projet | 27 sur 98 | Ses documents (+ ceux où il est validateur) | — |
| Responsable MEAL | 19 sur 98 | Ses documents (+ ceux où il est validateur) | — |
| Responsable de service | 22 sur 98 | Ses documents (+ ceux où il est validateur) | Responsable hiérarchique (≤ 500 USD) |
| Agent / personnel | 17 sur 98 | Ses documents (+ ceux où il est validateur) | — |

## Modules
Tableau de bord · Outils de gestion (98 outils codifiés du manuel) · Documents · À valider · Tâches et responsabilités · Manuel de procédures (PDF, accès par rubrique) · Modèles Word/Excel/PowerPoint · Enquêtes (publiques ou internes) · Recrutement (offres, formulaire public de candidature, suivi) · Rapports (Word, Excel, PowerPoint, CSV, PDF) · Administration.

## Liens publics (sans compte)
- Candidature : `https://<domaine>/#/candidature`
- Enquête publique : `https://<domaine>/#/e/<numéro>` (lien affiché dans la liste des enquêtes)
