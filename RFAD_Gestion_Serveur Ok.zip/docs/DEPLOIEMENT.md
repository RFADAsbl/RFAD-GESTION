# RFAD Gestion – Guide de déploiement

Application web (installable comme une application sur ordinateur et téléphone) : **un serveur central** héberge la base de données ; tous les postes et téléphones s'y connectent avec leur nom d'utilisateur et mot de passe.

## Choisir le mode d'installation

| Situation | Solution |
|---|---|
| Un ordinateur Windows allumé en permanence au bureau de Beni | **RFAD_Gestion_Setup.exe** → cocher « Serveur RFAD » (voir A) |
| Un serveur en ligne (VPS) accessible sur le domaine **rfad-asbl.org** | **Docker + Caddy** (voir B) ou **Cloudflare Tunnel** (voir C) |
| Les autres ordinateurs | **RFAD_Gestion_Setup.exe** → cocher « Accès client » seulement, ou simplement ouvrir l'adresse dans le navigateur |
| Téléphones (Android / iPhone) | Ouvrir l'adresse dans Chrome / Safari → « Installer l'application » / « Ajouter à l'écran d'accueil » |

> Les téléphones et les postes distants ont besoin d'une adresse accessible : le domaine (B ou C) est la solution recommandée. Un serveur uniquement sur le réseau local n'est joignable que depuis ce réseau.

## A. Poste Windows (Setup.exe)
1. Exécutez `RFAD_Gestion_Setup.exe` en tant qu'administrateur.
2. Cochez **Serveur RFAD** (poste central) et/ou **Accès client**. Saisissez l'adresse du système (par défaut `http://localhost:8080` pour le serveur, ou `https://app.rfad-asbl.org`).
3. Le **compte principal** est lié à `rfad.rdc@gmail.com` (connexion par cet e-mail ou par `admin`). Le mot de passe initial est inscrit dans `config.bat` (dossier `ProgramData\RFAD-Gestion`) : connectez-vous, changez-le (obligatoire), puis **supprimez la ligne `RFAD_ADMIN_PASSWORD`**.
4. Le serveur démarre automatiquement avec Windows (tâche planifiée « RFAD Gestion »). Données : `C:\ProgramData\RFAD-Gestion\data` (base `rfad.db` + pièces jointes). Journal : `C:\ProgramData\RFAD-Gestion\serveur.log`.
5. Autres postes du réseau : `http://<adresse-IP-du-serveur>:8080` (le pare-feu est ouvert pour les réseaux privés).
6. Paramètres (port, proxy) : `C:\ProgramData\RFAD-Gestion\config.bat`, puis redémarrer la tâche « RFAD Gestion ».
7. Mise à jour : relancer le nouveau Setup.exe (les données sont conservées).

## B. Serveur Linux sur le domaine (Docker + HTTPS automatique)
1. Créez chez Cloudflare un enregistrement DNS **A** `app` → IP publique du serveur (nuage *gris*, « DNS only », le temps d'obtenir le certificat).
2. Sur le serveur (Ubuntu + Docker) : copiez le dossier fourni, éditez `deploy/Caddyfile` si le sous-domaine diffère, puis :
   ```
   cd rfad-gestion/deploy
   docker compose up -d
   # créez d'abord deploy/.env contenant : RFAD_ADMIN_PASSWORD=<mot de passe initial>
   # (sinon : docker compose logs rfad | head -20 pour le mot de passe temporaire)
   ```
3. Ouvrez `https://app.rfad-asbl.org`. Sauvegardes : dossier `deploy/data/` (ou bouton « Sauvegarde » de l'administration).

## C. Cloudflare Tunnel (aucun port à ouvrir)
Voir `deploy/cloudflared-config.yml`. Lancez l'application (Setup.exe ou Docker sans Caddy) puis le tunnel ; dans `config.bat` (Windows) ou la variable d'environnement, mettez `RFAD_TRUST_PROXY=1` pour activer les cookies sécurisés.

## Sécurité en production
- Accès uniquement en **HTTPS** (Caddy ou Cloudflare) ; mettre `RFAD_TRUST_PROXY=1` derrière le proxy.
- Mots de passe hachés (scrypt), verrouillage 15 min après 5 échecs, sessions de 10 h, journal d'audit, signatures liées au contenu (SHA-256), contrôle CSRF, en-têtes CSP.
- **Sauvegardez chaque semaine** (Administration › Sauvegarde) et conservez la copie hors du serveur.
- Les données ne sont pas chiffrées sur le disque : protégez l'accès physique/au serveur.
- Pour une mise en service officielle : faire valider par le CA les seuils et délégations (Administration › Paramètres du manuel).

## Variables d'environnement
`RFAD_PORT` (8080) · `RFAD_HOST` (0.0.0.0) · `RFAD_DATA` (dossier des données) · `RFAD_TRUST_PROXY` (0/1) · `RFAD_ADMIN_EMAIL` (rfad.rdc@gmail.com par défaut) · `RFAD_ADMIN_PASSWORD` (mot de passe initial imposé, premier démarrage seulement, changement forcé à la 1re connexion).

## Test automatique
`npm install && npm test` n'est pas nécessaire en production ; `test/run.sh` exécute 95 contrôles (comptes, rôles, circuits, signatures, exports, sécurité) sur une base temporaire.

## E-mails (demandes d'accès → rfad.rdc@gmail.com)
Chaque demande d'accès est mise en file d'attente et envoyée à `rfad.rdc@gmail.com` (et aux autres administrateurs). Tant que le SMTP n'est pas configuré, les messages restent en attente et la demande est visible dans l'application (*Administration › Demandes d'accès*).
Configuration : *Administration › E-mails*. Pour Gmail : serveur `smtp.gmail.com`, port 465 (SSL), utilisateur `rfad.rdc@gmail.com`, et un **mot de passe d'application** Google (validation en 2 étapes requise) — le mot de passe du compte ne fonctionne pas. Utilisez « Envoyer un test » puis « Relancer » pour la file.
La validation reste dans l'application (connexion requise) : le lien du courriel n'approuve rien à lui seul.
