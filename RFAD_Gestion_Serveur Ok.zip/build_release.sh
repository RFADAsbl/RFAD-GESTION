#!/bin/bash
# Construit l'installateur Windows (Setup.exe) et le paquet de déploiement serveur
set -e
cd "$(dirname "$0")"
NODEWIN=/tmp/nodewin/package/bin/node.exe
rm -rf installer/stage dist && mkdir -p installer/stage/app installer/stage/node dist
cp -r server public package.json installer/stage/app/
rm -rf installer/stage/app/server/*.log
cp "$NODEWIN" installer/stage/node/node.exe
( cd installer/stage/app && npm install --omit=dev --no-audit --no-fund >/dev/null 2>&1 )
# allègement : fichiers inutiles à l'exécution (navigateur, types, cartes, docs)
rm -rf installer/stage/app/node_modules/exceljs/dist installer/stage/app/node_modules/@types
find installer/stage/app/node_modules -type f \( -name '*.map' -o -name '*.d.ts' -o -name '*.d.mts' -o -name '*.md' -o -name '*.markdown' \) -delete
find installer/stage/app/node_modules -type d \( -name test -o -name tests -o -name docs \) -prune -exec rm -rf {} + 2>/dev/null || true
( cd installer && makensis -V2 rfad.nsi && mv RFAD_Gestion_Setup.exe ../dist/ )
ls -la dist
