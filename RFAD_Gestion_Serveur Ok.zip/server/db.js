'use strict';
const { DatabaseSync } = require('node:sqlite');
const path = require('path'), fs = require('fs'), crypto = require('crypto');
const DATA = process.env.RFAD_DATA || path.join(__dirname, '..', 'data');
fs.mkdirSync(path.join(DATA, 'uploads'), { recursive: true });
const db = new DatabaseSync(path.join(DATA, 'rfad.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, email TEXT, phone TEXT,
  salt TEXT NOT NULL, hash TEXT NOT NULL, role TEXT DEFAULT 'AGENT', dept TEXT, post TEXT, responsibilities TEXT DEFAULT '', extra_tools TEXT DEFAULT '[]',
  status TEXT DEFAULT 'pending', requested_post TEXT, message TEXT, must_change INTEGER DEFAULT 0, failed INTEGER DEFAULT 0, locked_until INTEGER DEFAULT 0,
  created_at INTEGER, approved_by INTEGER, approved_at INTEGER, last_login INTEGER);
CREATE TABLE IF NOT EXISTS sessions(sid TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires INTEGER, ip TEXT, ua TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS docs(id INTEGER PRIMARY KEY, ref TEXT UNIQUE, code TEXT NOT NULL, dept TEXT, title TEXT, author_id INTEGER NOT NULL, status TEXT DEFAULT 'draft',
  data TEXT, amount REAL DEFAULT 0, version INTEGER DEFAULT 1, current_step INTEGER DEFAULT 0, project TEXT, created_at INTEGER, updated_at INTEGER, submitted_at INTEGER, closed_at INTEGER);
CREATE TABLE IF NOT EXISTS doc_versions(id INTEGER PRIMARY KEY, doc_id INTEGER, version INTEGER, data TEXT, title TEXT, amount REAL, by_user INTEGER, reason TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS approvals(id INTEGER PRIMARY KEY, doc_id INTEGER, round INTEGER DEFAULT 1, step INTEGER, role TEXT, label TEXT, assignee_id INTEGER, status TEXT DEFAULT 'waiting',
  comment TEXT, signature TEXT, sig_hash TEXT, signed_at INTEGER, signer_name TEXT, doa INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS attachments(id INTEGER PRIMARY KEY, doc_id INTEGER, name TEXT, mime TEXT, size INTEGER, file TEXT, by_user INTEGER, at INTEGER);
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, title TEXT, description TEXT, assignee_id INTEGER, created_by INTEGER, due TEXT, status TEXT DEFAULT 'open', doc_id INTEGER, procedure_ref TEXT, created_at INTEGER, done_at INTEGER);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, user_id INTEGER, text TEXT, link TEXT, read INTEGER DEFAULT 0, at INTEGER);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, at INTEGER, user_id INTEGER, username TEXT, action TEXT, target TEXT, detail TEXT, ip TEXT);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY, to_addr TEXT, subject TEXT, body TEXT, status TEXT DEFAULT 'pending', tries INTEGER DEFAULT 0, error TEXT DEFAULT '', at INTEGER, sent_at INTEGER);
CREATE TABLE IF NOT EXISTS surveys(id INTEGER PRIMARY KEY, title TEXT, description TEXT, schema TEXT, is_public INTEGER DEFAULT 0, status TEXT DEFAULT 'open', created_by INTEGER, created_at INTEGER);
CREATE TABLE IF NOT EXISTS survey_responses(id INTEGER PRIMARY KEY, survey_id INTEGER, data TEXT, user_id INTEGER, at INTEGER, ip TEXT);
CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY, ref TEXT, title TEXT, dept TEXT, location TEXT, contract TEXT, description TEXT, profile TEXT, deadline TEXT, status TEXT DEFAULT 'open', created_by INTEGER, created_at INTEGER);
CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY, job_id INTEGER, data TEXT, status TEXT DEFAULT 'new', score REAL, notes TEXT, at INTEGER, ip TEXT);
CREATE INDEX IF NOT EXISTS ix_docs_author ON docs(author_id); CREATE INDEX IF NOT EXISTS ix_appr_assignee ON approvals(assignee_id,status); CREATE INDEX IF NOT EXISTS ix_sess_user ON sessions(user_id);
`);
const run = (sql, ...p) => db.prepare(sql).run(...p);
const get = (sql, ...p) => db.prepare(sql).get(...p);
const all = (sql, ...p) => db.prepare(sql).all(...p);
const now = () => Date.now();
function tx(fn) { db.exec('BEGIN IMMEDIATE'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } }
function audit(user, action, target, detail, ip) { run('INSERT INTO audit(at,user_id,username,action,target,detail,ip) VALUES(?,?,?,?,?,?,?)', now(), user ? user.id : null, user ? user.username : '-', action, String(target || ''), detail ? String(detail).slice(0, 1000) : '', ip || ''); }
function notify(userId, text, link) { if (userId) run('INSERT INTO notifications(user_id,text,link,at) VALUES(?,?,?,?)', userId, text, link || '', now()); }
function setting(k, def) { const r = get('SELECT v FROM settings WHERE k=?', k); if (!r) return def; try { return JSON.parse(r.v); } catch (e) { return def; } }
function setSetting(k, v) { run('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', k, JSON.stringify(v)); }
module.exports = { db, run, get, all, now, tx, audit, notify, setting, setSetting, DATA };
