'use strict';
// Rôles, permissions et circuits de validation, alignés sur le Manuel de procédures RFAD ASBL (2026)
const ROLES = {
  ADMIN: { label: 'Administrateur système', all: true },
  PRES:  { label: 'Présidente du Conseil d’Administration', all: true },
  TRES:  { label: 'Trésorière générale', all: true },
  CA:    { label: 'Membre du Conseil d’Administration', all: true },
  DE:    { label: 'Directeur exécutif', all: true },
  COORD: { label: 'Coordination générale', all: true },
  CC:    { label: 'Commission de contrôle', all: true },
  ADM:   { label: 'Responsable administratif', depts: ['ADM'] },
  SECR:  { label: 'Secrétariat', depts: ['ADM'] },
  RH:    { label: 'Responsable des ressources humaines', depts: ['RH'] },
  FIN:   { label: 'Responsable finances', depts: ['FIN'] },
  CAIS:  { label: 'Caissier(ère)', depts: [], only: ['FIN-02', 'FIN-03', 'FIN-04', 'FIN-08', 'FIN-09'] },
  CPT:   { label: 'Comptable', depts: ['CPT', 'FIN'] },
  LOG:   { label: 'Responsable logistique et achats', depts: ['LOG'] },
  MAG:   { label: 'Magasinier', depts: [], only: ['LOG-06', 'LOG-07', 'LOG-08', 'LOG-09', 'LOG-10', 'LOG-18', 'LOG-20'] },
  CHAUF: { label: 'Chauffeur', depts: [], only: ['LOG-14', 'LOG-15', 'LOG-16', 'LOG-19', 'SEC-02'] },
  SEC:   { label: 'Focal point sécurité', depts: ['SEC'] },
  PSEAH: { label: 'Point focal PSEAH / protection', depts: [], only: ['SEC-10', 'SEC-11', 'SEC-12', 'ADM-10'] },
  PROJ:  { label: 'Chef de projet', depts: [], only: ['FIN-13', 'FIN-14', 'FIN-15', 'FIN-16', 'LOG-10', 'LOG-11', 'LOG-17', 'RH-01', 'ADM-06', 'ADM-07'] },
  MEAL:  { label: 'Responsable MEAL', depts: [], only: ['ADM-06', 'ADM-10', 'LOG-11'] },
  RESP:  { label: 'Responsable de service', depts: [], only: ['RH-01', 'RH-15', 'RH-17', 'ADM-06', 'FIN-15'] },
  AGENT: { label: 'Agent / personnel', depts: [] },
};
// Outils accessibles à tout le personnel (demandes, missions, déclarations)
const BASE = ['ADM-03', 'ADM-04', 'ADM-05', 'ADM-10', 'ADM-11', 'ADM-12', 'ADM-15', 'FIN-01', 'FIN-05', 'FIN-06', 'FIN-07', 'LOG-01', 'LOG-19', 'RH-13', 'SEC-02', 'SEC-10', 'SEC-04'];
const VIEW_ALL = ['ADMIN', 'PRES', 'TRES', 'CA', 'DE', 'COORD', 'CC'];

function short(code) { return code.replace(/^OUT-/, ''); }
function canCreate(user, code) {
  if (!user || user.status !== 'active') return false;
  const r = ROLES[user.role] || ROLES.AGENT, s = short(code), dept = s.split('-')[0];
  if (user.role === 'ADMIN' || ['DE', 'COORD'].includes(user.role)) return true;
  if (BASE.includes(s)) return true;
  if (r.depts && r.depts.includes(dept)) return true;
  if (r.only && r.only.includes(s)) return true;
  if (user.role === 'TRES' && ['FIN', 'CPT'].includes(dept)) return true;
  try { if (JSON.parse(user.extra_tools || '[]').includes(s)) return true; } catch (e) {}
  return false;
}
function canViewAll(user) { return VIEW_ALL.includes(user.role); }
function viewDepts(user) {
  const r = ROLES[user.role] || {}; const d = new Set(r.depts || []);
  if (user.dept) d.add(user.dept);
  return [...d];
}

// ---- circuit de validation d'après les rubriques de signature du manuel
function stepRole(label) {
  const l = label.toLowerCase();
  if (/signataire a/.test(l)) return 'TRES';
  if (/signataire b/.test(l)) return 'DE';
  if (/autorit|autorisateur/.test(l)) return 'DOA';
  if (/directeur exécutif/.test(l)) return 'DE';
  if (/trésori/.test(l)) return 'TRES';
  if (/pris acte|\(reçu\)|pour acquit|signature de l’agent|évalué|agent sortant|fournisseur|représentant|témoin|bénéficiaire|déposant|délégataire|personne concernée|titulaire|responsable du service destinataire/.test(l)) return 'EXT';
  if (/responsable finance|^finance|membre \/ finance|préparé par \(finance\)/.test(l)) return 'FIN';
  if (/comptable|contrôleur/.test(l)) return 'CPT';
  if (/caissier/.test(l)) return 'CAIS';
  if (/magasinier/.test(l)) return 'MAG';
  if (/logistique/.test(l)) return 'LOG';
  if (/focal point/.test(l)) return 'SEC';
  if (/pseah|responsable protection/.test(l)) return 'PSEAH';
  if (/responsable rh/.test(l)) return 'RH';
  if (/responsable administratif/.test(l)) return 'ADM';
  if (/hiérarchique|supérieur|responsable de service|^responsable$/.test(l)) return 'RESP';
  if (/président|chef de mission|^membre/.test(l)) return 'ANY';
  return 'AUTHOR';
}
// Matrice des délégations (USD) – modifiable par l'administrateur dans les paramètres
const DEFAULT_PARAMS = {
  doa: [ { max: 500, role: 'RESP', label: 'Responsable de service / chef de projet' }, { max: 5000, role: 'COORD', label: 'Coordination générale' },
         { max: 25000, role: 'DE', label: 'Directeur exécutif' }, { max: 100000, role: 'TRES', label: 'Directeur exécutif + Trésorière générale' }, { max: null, role: 'PRES', label: 'Conseil d’Administration (Présidente)' } ],
  purchase: [ { max: 100, code: 'P0', label: 'Achat direct (petite caisse)' }, { max: 2500, code: 'P1', label: 'Achat simple – une cotation' }, { max: 15000, code: 'P2', label: 'Procédure négociée – 3 devis' },
              { max: 30000, code: 'P3', label: 'Cotations formelles – comité d’achat' }, { max: 100000, code: 'P4', label: 'Appel d’offres national' }, { max: null, code: 'P5', label: 'Appel d’offres international' } ],
  caisse: { soldeMaxSiege: 1000, soldeMaxAntenne: 500, maxOperation: 100, avanceMax: 2500 },
  immobilisation: 500, recrutementJours: 45, alerteIncidentHeures: 2, rapportIncidentHeures: 24,
};
function requiredRoles(amount, params) {
  const p = params || DEFAULT_PARAMS; const a = Number(amount) || 0; const out = [];
  if (a > 500) out.push('COORD'); if (a > 5000) { out.length = 0; out.push('DE'); }
  if (a > 25000) out.push('TRES'); if (a > 100000) out.push('PRES');
  return out;
}
function buildChain(form, amount, params) {
  const signs = form.blocks.filter(b => b.type === 'sign').flatMap(b => b.roles);
  const steps = []; const ext = [];
  signs.forEach(label => {
    const r = stepRole(label);
    if (r === 'AUTHOR') return;
    if (r === 'EXT') { ext.push(label); return; }
    if (r === 'DOA') { const req = requiredRoles(amount, params); (req.length ? req : ['RESP']).forEach(x => steps.push({ role: x, label: label + ' – selon matrice des délégations', doa: true })); return; }
    steps.push({ role: r, label });
  });
  // dédoublonnage
  const seen = new Set(); let chain = steps.filter(s => { const k = s.role; if (seen.has(k)) return false; seen.add(k); return true; });
  if (!chain.length) chain = [{ role: 'RESP', label: 'Responsable hiérarchique' }];
  // assurer la couverture de la matrice des délégations selon le montant
  requiredRoles(amount, params).forEach(x => { if (!seen.has(x)) { chain.push({ role: x, label: 'Approbation – matrice des délégations (' + x + ')', doa: true }); seen.add(x); } });
  return { steps: chain.map((s, i) => ({ step: i + 1, ...s })), ext };
}
module.exports = { ROLES, BASE, canCreate, canViewAll, viewDepts, stepRole, buildChain, DEFAULT_PARAMS, requiredRoles, short };
