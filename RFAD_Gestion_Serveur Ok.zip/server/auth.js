'use strict';
const crypto = require('crypto');
const { run, get, all, now, audit } = require('./db');
function hashPwd(pwd, salt) { salt = salt || crypto.randomBytes(16).toString('hex'); return { salt, hash: crypto.scryptSync(pwd, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex') }; }
function checkPwd(pwd, salt, hash) { const h = crypto.scryptSync(pwd, salt, 64, { N: 16384, r: 8, p: 1 }); const b = Buffer.from(hash, 'hex'); return b.length === h.length && crypto.timingSafeEqual(h, b); }
function pwdPolicy(pwd, username) {
  if (typeof pwd !== 'string' || pwd.length < 10) return 'Le mot de passe doit contenir au moins 10 caractères.';
  if (!/[A-Za-z]/.test(pwd) || !/[0-9]/.test(pwd)) return 'Le mot de passe doit contenir des lettres et des chiffres.';
  if (username && pwd.toLowerCase().includes(String(username).toLowerCase())) return 'Le mot de passe ne doit pas contenir le nom d’utilisateur.';
  if (/^(.)\1+$/.test(pwd) || /(password|motdepasse|123456|azerty|qwerty)/i.test(pwd)) return 'Mot de passe trop prévisible.';
  return null;
}
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const SESSION_MS = 10 * 3600 * 1000;
function createSession(userId, ip, ua) { const sid = crypto.randomBytes(32).toString('base64url'); run('INSERT INTO sessions(sid,user_id,expires,ip,ua,created_at) VALUES(?,?,?,?,?,?)', sha(sid), userId, now() + SESSION_MS, ip, String(ua || '').slice(0, 200), now()); return sid; }
function sessionUser(sid) {
  if (!sid) return null; const s = get('SELECT * FROM sessions WHERE sid=?', sha(sid)); if (!s) return null;
  if (s.expires < now()) { run('DELETE FROM sessions WHERE sid=?', s.sid); return null; }
  const u = get('SELECT * FROM users WHERE id=?', s.user_id); if (!u || u.status !== 'active') return null;
  if (s.expires - now() < SESSION_MS - 600000) run('UPDATE sessions SET expires=? WHERE sid=?', now() + SESSION_MS, s.sid);
  return u;
}
function destroySession(sid) { if (sid) run('DELETE FROM sessions WHERE sid=?', sha(sid)); }
function destroyUserSessions(uid) { run('DELETE FROM sessions WHERE user_id=?', uid); }
// limitation de débit en mémoire
const buckets = new Map();
function rate(key, max, windowMs) { const t = now(); let b = buckets.get(key); if (!b || b.reset < t) b = { n: 0, reset: t + windowMs }; b.n++; buckets.set(key, b); if (buckets.size > 5000) for (const [k, v] of buckets) if (v.reset < t) buckets.delete(k); return b.n <= max; }
function publicUser(u) { if (!u) return null; const { salt, hash, failed, locked_until, ...rest } = u; return rest; }
module.exports = { hashPwd, checkPwd, pwdPolicy, createSession, sessionUser, destroySession, destroyUserSessions, rate, publicUser, sha };
