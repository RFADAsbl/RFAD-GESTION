'use strict';
const fs = require('fs'), path = require('path');
const D = require('docx'); const ExcelJS = require('exceljs'); const PptxGenJS = require('pptxgenjs');
const PUB = path.join(__dirname, '..', 'public', 'img');
const LOGO = fs.readFileSync(path.join(PUB, 'logo.png'));
const COLORS = { ADM: '5B2A86', RH: '1B1F4B', FIN: 'E8A317', CPT: '2F5DA8', LOG: '4E9A2F', SEC: 'C2397F', GEN: '5B2A86' };
const ECLAT = { ADM: 'purple', RH: 'navy', FIN: 'gold', CPT: 'blue', LOG: 'green', SEC: 'pink', GEN: 'purple' };
const eclat = d => fs.readFileSync(path.join(PUB, `eclat_${ECLAT[d] || 'purple'}.png`));
const STATUS = { draft: 'Brouillon', review: 'En validation', approved: 'Validé', rejected: 'Retourné pour correction', archived: 'Archivé' };
const fmtDate = t => t ? new Date(t).toLocaleString('fr-FR', { timeZone: 'Africa/Lubumbashi', dateStyle: 'short', timeStyle: 'short' }) : '';
const ORG = 'RFAD ASBL – Réseau des Femmes pour l’Aide et le Développement';

function normalize(form, data) {
  const bl = (data && data.blocks) || [];
  return form.blocks.map((b, i) => {
    const d = bl[i] || {};
    if (b.type === 'fields') return { kind: 'fields', rows: b.items.map((it, j) => [it.label, (d.values && d.values[j]) || '']) };
    if (b.type === 'text') return { kind: 'text', label: b.label, value: d.value || '' };
    if (b.type === 'grid') return { kind: 'grid', headers: b.headers, rows: (d.rows || []).filter(r => r && r.some(c => String(c || '').trim())) };
    if (b.type === 'check') return { kind: 'check', cols: b.cols, rows: b.items.map((it, j) => [it, (d.answers && d.answers[j] != null && d.answers[j] >= 0) ? b.cols[d.answers[j]] : '—', (d.obs && d.obs[j]) || '']) };
    if (b.type === 'sign') return { kind: 'sign', roles: b.roles };
    return { kind: 'note', text: b.text };
  });
}
function ctxMeta(c) {
  const m = (c.data && c.data.meta) || {};
  return [['Référence', c.doc.ref], ['Code de l’outil', c.doc.code], ['Statut', STATUS[c.doc.status] || c.doc.status], ['Version', String(c.doc.version)], ['Établi par', c.author.name + (c.author.post ? ' – ' + c.author.post : '')],
    ['Date du document', m.date || fmtDate(c.doc.created_at)], ['Projet / bailleur', c.doc.project || m.project || ''], ['Montant concerné (USD)', c.doc.amount ? String(c.doc.amount) : '']].filter(r => r[1]);
}
const dataUrlBuf = s => { const m = /^data:image\/png;base64,(.+)$/.exec(s || ''); return m ? Buffer.from(m[1], 'base64') : null; };

// ------------------------------------------------------------------ WORD
async function docToDocx(c) {
  const col = COLORS[c.form.dept] || COLORS.GEN;
  const border = { style: D.BorderStyle.SINGLE, size: 4, color: 'BFB6D2' };
  const borders = { top: border, bottom: border, left: border, right: border };
  const P = (t, o = {}) => new D.Paragraph({ spacing: { after: o.after ?? 60 }, alignment: o.align, children: [new D.TextRun({ text: String(t ?? ''), bold: o.bold, size: o.size || 19, color: o.color, font: 'Calibri', italics: o.italics })] });
  const cell = (t, o = {}) => new D.TableCell({ borders, width: { size: o.w || 2000, type: D.WidthType.DXA }, shading: o.fill ? { type: D.ShadingType.CLEAR, color: 'auto', fill: o.fill } : undefined, margins: { top: 50, bottom: 50, left: 90, right: 90 }, columnSpan: o.span, verticalAlign: D.VerticalAlign.CENTER,
    children: String(t ?? '').split('\n').map(x => P(x, { bold: o.bold, color: o.color, size: o.size || 18, after: 0 })) });
  const W = 9800; const kids = [];
  const light = { '5B2A86': 'F1EBF7', '1B1F4B': 'E8E9F2', 'E8A317': 'FDF3DC', '2F5DA8': 'E7EEF8', '4E9A2F': 'EAF4E4', 'C2397F': 'FBEAF2' }[col];
  kids.push(new D.Table({ width: { size: W, type: D.WidthType.DXA }, columnWidths: [2000, 5800, 2000], rows: [new D.TableRow({ children: [cell(c.form.code, { w: 2000, fill: col, bold: true, color: 'FFFFFF', size: 20 }), cell(c.form.title + (c.form.sub ? '\n' + c.form.sub : ''), { w: 5800, fill: col, bold: true, color: 'FFFFFF', size: 22 }), cell('RFAD ASBL\nBeni · Nord-Kivu · RDC', { w: 2000, fill: col, color: 'FFFFFF', size: 16 })] })] }));
  kids.push(P('', { after: 80 }));
  kids.push(new D.Table({ width: { size: W, type: D.WidthType.DXA }, columnWidths: [2400, 2500, 2400, 2500], rows: chunk(ctxMeta(c), 2).map(r => new D.TableRow({ children: [cell(r[0][0], { w: 2400, fill: light, bold: true, color: col }), cell(r[0][1], { w: 2500 }), cell(r[1] ? r[1][0] : '', { w: 2400, fill: r[1] ? light : undefined, bold: true, color: col }), cell(r[1] ? r[1][1] : '', { w: 2500 })] })) }));
  kids.push(P('', { after: 80 }));
  if (c.doc.title) kids.push(P('Objet : ' + c.doc.title, { bold: true, size: 22, color: col, after: 100 }));
  for (const b of normalize(c.form, c.data)) {
    if (b.kind === 'fields') kids.push(new D.Table({ width: { size: W, type: D.WidthType.DXA }, columnWidths: [2400, 2500, 2400, 2500], rows: chunk(b.rows, 2).map(r => new D.TableRow({ children: [cell(r[0][0], { w: 2400, fill: light, bold: true, color: col }), cell(r[0][1], { w: 2500 }), cell(r[1] ? r[1][0] : '', { w: 2400, fill: r[1] ? light : undefined, bold: true, color: col }), cell(r[1] ? r[1][1] : '', { w: 2500 })] })) }));
    else if (b.kind === 'text') kids.push(new D.Table({ width: { size: W, type: D.WidthType.DXA }, columnWidths: [W], rows: [new D.TableRow({ children: [cell(b.label, { w: W, fill: light, bold: true, color: col })] }), new D.TableRow({ children: [cell(b.value || ' ', { w: W })] })] }));
    else if (b.kind === 'grid') { const w = Math.floor(W / b.headers.length); kids.push(new D.Table({ width: { size: w * b.headers.length, type: D.WidthType.DXA }, columnWidths: b.headers.map(() => w), rows: [new D.TableRow({ tableHeader: true, children: b.headers.map(h => cell(h, { w, fill: light, bold: true, color: col, size: 16 })) }), ...(b.rows.length ? b.rows : [b.headers.map(() => '')]).map(r => new D.TableRow({ children: b.headers.map((h, j) => cell(r[j] || '', { w, size: 16 })) }))] })); }
    else if (b.kind === 'check') kids.push(new D.Table({ width: { size: W, type: D.WidthType.DXA }, columnWidths: [5400, 1600, 2800], rows: [new D.TableRow({ children: [cell('Point de contrôle', { w: 5400, fill: light, bold: true, color: col }), cell(b.cols.join(' / '), { w: 1600, fill: light, bold: true, color: col }), cell('Observation', { w: 2800, fill: light, bold: true, color: col })] }), ...b.rows.map(r => new D.TableRow({ children: [cell(r[0], { w: 5400 }), cell(r[1], { w: 1600 }), cell(r[2], { w: 2800 })] }))] }));
    else if (b.kind === 'note') kids.push(P(b.text, { italics: true, size: 16, color: '6B678A' }));
    if (b.kind !== 'note') kids.push(P('', { after: 70 }));
  }
  // signatures électroniques
  kids.push(P('Circuit de validation et signatures', { bold: true, size: 22, color: col }));
  const sw = Math.floor(W / Math.max(1, Math.min(3, c.approvals.length + 1)));
  const sigCells = [];
  const authSig = dataUrlBuf(c.authorSig && c.authorSig.signature);
  const mk = (title, name, when, sig, status) => new D.TableCell({ borders, width: { size: sw, type: D.WidthType.DXA }, margins: { top: 60, bottom: 60, left: 90, right: 90 }, children: [P(title, { bold: true, color: col, size: 17, after: 20 }), sig ? new D.Paragraph({ children: [new D.ImageRun({ type: 'png', data: sig, transformation: { width: 120, height: 45 } })] }) : P(status || '', { size: 16, color: '6B678A', italics: true }), P(name, { size: 16, after: 0 }), P(when, { size: 14, color: '6B678A', after: 0 })] });
  sigCells.push(mk('Établi par (auteur)', c.author.name, c.doc.submitted_at ? fmtDate(c.doc.submitted_at) : '', authSig, 'Non signé'));
  c.approvals.forEach(a => sigCells.push(mk(a.label || a.role, a.signer_name || a.assignee_name || '', a.signed_at ? fmtDate(a.signed_at) + (a.sig_hash ? ' · ' + a.sig_hash.slice(0, 12) : '') : '', dataUrlBuf(a.signature), a.status === 'waiting' ? 'En attente' : a.status === 'pending' ? 'À signer' : a.status === 'rejected' ? 'Retourné : ' + (a.comment || '') : '')));
  chunk(sigCells, 3).forEach(r => { while (r.length < 3) r.push(new D.TableCell({ borders, width: { size: sw, type: D.WidthType.DXA }, children: [P('')] })); });
  kids.push(new D.Table({ width: { size: sw * 3, type: D.WidthType.DXA }, columnWidths: [sw, sw, sw], rows: chunk(sigCells, 3).map(r => new D.TableRow({ children: r })) }));
  if (c.form.blocks.length) { const ext = c.form.blocks.filter(b => b.type === 'sign').flatMap(b => b.roles).filter(l => require('./roles').stepRole(l) === 'EXT'); if (ext.length) { kids.push(P('', { after: 60 })); kids.push(P('Signatures manuscrites à recueillir sur la version imprimée : ' + ext.join(' · '), { size: 16, italics: true, color: '6B678A' })); } }
  const header = new D.Header({ children: [new D.Table({ width: { size: W, type: D.WidthType.DXA }, columnWidths: [900, 8900], borders: { top: { style: 'none' }, bottom: { style: D.BorderStyle.SINGLE, size: 12, color: 'E8A317' }, left: { style: 'none' }, right: { style: 'none' }, insideHorizontal: { style: 'none' }, insideVertical: { style: 'none' } },
    rows: [new D.TableRow({ children: [new D.TableCell({ borders: noB(), width: { size: 900, type: D.WidthType.DXA }, children: [new D.Paragraph({ children: [new D.ImageRun({ type: 'png', data: LOGO, transformation: { width: 52, height: 52 } })] })] }), new D.TableCell({ borders: noB(), width: { size: 8900, type: D.WidthType.DXA }, verticalAlign: D.VerticalAlign.CENTER, children: [P(ORG, { bold: true, color: col, size: 20, after: 0 }), P('Manuel de procédures de gestion · Beni, Nord-Kivu, RDC', { size: 15, color: '6B678A', after: 0 })] })] })] })] });
  const footer = new D.Footer({ children: [P(`${c.doc.ref} · ${STATUS[c.doc.status] || ''} · généré le ${fmtDate(Date.now())}`, { size: 14, color: '6B678A', align: D.AlignmentType.CENTER })] });
  const d = new D.Document({ creator: 'RFAD ASBL', title: c.form.title, styles: { default: { document: { run: { font: 'Calibri', size: 19 } } } }, sections: [{ properties: { page: { margin: { top: 1500, bottom: 900, left: 1000, right: 1000 }, size: { width: 11906, height: 16838 } } }, headers: { default: header }, footers: { default: footer }, children: kids }] });
  return D.Packer.toBuffer(d);
}
const noB = () => { const n = { style: D.BorderStyle.NONE, size: 0, color: 'FFFFFF' }; return { top: n, bottom: n, left: n, right: n }; };
function chunk(a, n) { const o = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; }

// ------------------------------------------------------------------ EXCEL
async function docToXlsx(c) {
  const col = COLORS[c.form.dept] || COLORS.GEN; const wb = new ExcelJS.Workbook(); wb.creator = 'RFAD ASBL';
  const ws = wb.addWorksheet(c.form.code.replace('OUT-', '').slice(0, 30), { pageSetup: { paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
  ws.columns = [{ width: 30 }, { width: 28 }, { width: 24 }, { width: 24 }, { width: 18 }, { width: 18 }, { width: 18 }];
  const logoId = wb.addImage({ buffer: LOGO, extension: 'png' }); ws.addImage(logoId, { tl: { col: 0, row: 0 }, ext: { width: 60, height: 60 } });
  ws.getRow(1).height = 24; ws.getRow(2).height = 24;
  ws.getCell('B1').value = ORG; ws.getCell('B1').font = { bold: true, size: 13, color: { argb: 'FF' + col } };
  ws.getCell('B2').value = c.form.code + ' – ' + c.form.title; ws.getCell('B2').font = { bold: true, size: 12 };
  let r = 4; const fill = f => ({ type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + f } });
  const hdr = cell => { cell.fill = fill(col); cell.font = { bold: true, color: { argb: 'FFFFFFFF' } }; cell.border = bd(); cell.alignment = { wrapText: true, vertical: 'middle' }; };
  const bd = () => ({ top: { style: 'thin', color: { argb: 'FFBFB6D2' } }, bottom: { style: 'thin', color: { argb: 'FFBFB6D2' } }, left: { style: 'thin', color: { argb: 'FFBFB6D2' } }, right: { style: 'thin', color: { argb: 'FFBFB6D2' } } });
  const kv = (k, v) => { const a = ws.getCell(r, 1), b = ws.getCell(r, 2); a.value = k; b.value = v; a.font = { bold: true }; a.fill = fill('F1EBF7'); a.border = bd(); b.border = bd(); b.alignment = { wrapText: true, vertical: 'top' }; ws.mergeCells(r, 2, r, 4); r++; };
  ctxMeta(c).forEach(([k, v]) => kv(k, v)); if (c.doc.title) kv('Objet', c.doc.title); r++;
  for (const b of normalize(c.form, c.data)) {
    if (b.kind === 'fields') { b.rows.forEach(([k, v]) => kv(k, v)); r++; }
    else if (b.kind === 'text') { const a = ws.getCell(r, 1); a.value = b.label; hdr(a); ws.mergeCells(r, 1, r, 4); r++; const t = ws.getCell(r, 1); t.value = b.value; t.alignment = { wrapText: true, vertical: 'top' }; ws.mergeCells(r, 1, r, 4); ws.getRow(r).height = Math.max(30, 15 * Math.ceil((b.value || '').length / 90)); r += 2; }
    else if (b.kind === 'grid') { b.headers.forEach((h, j) => { const x = ws.getCell(r, j + 1); x.value = h; hdr(x); }); const first = r + 1; r++; (b.rows.length ? b.rows : [[]]).forEach(row => { b.headers.forEach((h, j) => { const x = ws.getCell(r, j + 1); const v = row[j]; const n = v !== undefined && v !== '' && !isNaN(Number(String(v).replace(',', '.'))) && /montant|total|quantité|prix|valeur|entr|sorti|solde|coût|cout/i.test(h) ? Number(String(v).replace(',', '.')) : v; x.value = n; x.border = bd(); x.alignment = { wrapText: true, vertical: 'top' }; }); r++; }); b.headers.forEach((h, j) => { if (/montant|total|quantité|valeur/i.test(h)) { const x = ws.getCell(r, j + 1); x.value = { formula: `SUM(${ws.getCell(first, j + 1).address}:${ws.getCell(r - 1, j + 1).address})` }; x.font = { bold: true }; x.border = bd(); } }); const tl = ws.getCell(r, 1); if (b.headers.some(h => /montant|total|quantité|valeur/i.test(h))) { tl.value = 'Total'; tl.font = { bold: true }; } r += 2; }
    else if (b.kind === 'check') { ['Point de contrôle', b.cols.join(' / '), 'Observation'].forEach((h, j) => { const x = ws.getCell(r, j + 1); x.value = h; hdr(x); }); r++; b.rows.forEach(row => { row.forEach((v, j) => { const x = ws.getCell(r, j + 1); x.value = v; x.border = bd(); x.alignment = { wrapText: true, vertical: 'top' }; }); r++; }); r++; }
    else if (b.kind === 'note') { ws.getCell(r, 1).value = b.text; ws.getCell(r, 1).font = { italic: true, color: { argb: 'FF6B678A' } }; ws.mergeCells(r, 1, r, 5); ws.getCell(r, 1).alignment = { wrapText: true }; ws.getRow(r).height = 30; r += 2; }
  }
  const h = ws.getCell(r, 1); h.value = 'Circuit de validation'; hdr(h); ws.mergeCells(r, 1, r, 4); r++;
  const rows = [['Auteur', c.author.name, fmtDate(c.doc.submitted_at), 'Signé']].concat(c.approvals.map(a => [a.label || a.role, a.signer_name || a.assignee_name, fmtDate(a.signed_at), a.status === 'approved' ? 'Validé · ' + (a.sig_hash || '').slice(0, 12) : a.status === 'rejected' ? 'Retourné : ' + (a.comment || '') : 'En attente']));
  rows.forEach(rw => { rw.forEach((v, j) => { const x = ws.getCell(r, j + 1); x.value = v; x.border = bd(); }); r++; });
  ws.headerFooter.oddFooter = '&L' + c.doc.ref + '&RPage &P/&N';
  return Buffer.from(await wb.xlsx.writeBuffer());
}

// ------------------------------------------------------------------ POWERPOINT
async function docToPptx(c) {
  const col = COLORS[c.form.dept] || COLORS.GEN; const p = new PptxGenJS(); p.layout = 'LAYOUT_WIDE'; p.title = c.form.title; p.author = 'RFAD ASBL';
  const logo = 'data:image/png;base64,' + LOGO.toString('base64'), ec = 'data:image/png;base64,' + eclat(c.form.dept).toString('base64');
  const base = (s, title) => { s.background = { color: 'FFFFFF' }; s.addImage({ data: ec, x: 10.4, y: -0.6, w: 3.6, h: 3.6, transparency: 70 }); s.addImage({ data: logo, x: 0.4, y: 0.25, w: 0.8, h: 0.8 }); s.addText(title, { x: 1.4, y: 0.3, w: 9, h: 0.7, fontSize: 24, bold: true, color: col, fontFace: 'Calibri' }); s.addShape(p.ShapeType.line, { x: 0.4, y: 1.15, w: 12.5, h: 0, line: { color: 'E8A317', width: 2 } }); s.addText(`${c.doc.ref} · RFAD ASBL`, { x: 0.4, y: 7.05, w: 12.5, h: 0.3, fontSize: 10, color: '6B678A', align: 'center' }); };
  let s = p.addSlide(); s.background = { color: col }; s.addImage({ data: logo, x: 0.6, y: 0.5, w: 1.4, h: 1.4 });
  s.addText(c.form.title, { x: 0.6, y: 2.4, w: 12, h: 1.5, fontSize: 38, bold: true, color: 'FFFFFF', fontFace: 'Calibri' });
  s.addText(`${c.form.code} · ${c.doc.ref}\n${STATUS[c.doc.status]} · ${c.author.name}`, { x: 0.6, y: 4.2, w: 12, h: 1.2, fontSize: 18, color: 'FFFFFF' });
  s.addText(ORG, { x: 0.6, y: 6.6, w: 12, h: 0.5, fontSize: 14, color: 'FFFFFF' });
  s = p.addSlide(); base(s, 'Informations générales');
  s.addTable(ctxMeta(c).concat(c.doc.title ? [['Objet', c.doc.title]] : []).map(r => [{ text: r[0], options: { bold: true, color: col, fill: { color: 'F1EBF7' } } }, { text: r[1] }]), { x: 0.5, y: 1.4, w: 12.3, colW: [3.5, 8.8], fontSize: 14, border: { type: 'solid', color: 'BFB6D2', pt: 0.5 } });
  for (const b of normalize(c.form, c.data)) {
    if (b.kind === 'fields') { for (const part of chunk(b.rows, 9)) { s = p.addSlide(); base(s, 'Détails'); s.addTable(part.map(r => [{ text: r[0], options: { bold: true, color: col, fill: { color: 'F1EBF7' } } }, { text: String(r[1] || '—') }]), { x: 0.5, y: 1.4, w: 12.3, colW: [4.5, 7.8], fontSize: 13, border: { type: 'solid', color: 'BFB6D2', pt: 0.5 } }); } }
    else if (b.kind === 'text') { s = p.addSlide(); base(s, b.label.slice(0, 70)); s.addText(b.value || '—', { x: 0.6, y: 1.4, w: 12, h: 5.4, fontSize: 16, valign: 'top', fontFace: 'Calibri' }); }
    else if (b.kind === 'grid') { for (const part of chunk(b.rows.length ? b.rows : [b.headers.map(() => '')], 8)) { s = p.addSlide(); base(s, 'Tableau'); s.addTable([b.headers.map(h => ({ text: h, options: { bold: true, color: 'FFFFFF', fill: { color: col } } }))].concat(part.map(r => b.headers.map((h, j) => ({ text: String(r[j] || '') })))), { x: 0.4, y: 1.4, w: 12.5, fontSize: 11, border: { type: 'solid', color: 'BFB6D2', pt: 0.5 } }); } }
    else if (b.kind === 'check') { for (const part of chunk(b.rows, 9)) { s = p.addSlide(); base(s, 'Points de contrôle'); s.addTable([[{ text: 'Point', options: { bold: true, color: 'FFFFFF', fill: { color: col } } }, { text: b.cols.join('/'), options: { bold: true, color: 'FFFFFF', fill: { color: col } } }, { text: 'Observation', options: { bold: true, color: 'FFFFFF', fill: { color: col } } }]].concat(part.map(r => r.map(v => ({ text: String(v) })))), { x: 0.4, y: 1.4, w: 12.5, colW: [7.3, 1.7, 3.5], fontSize: 12, border: { type: 'solid', color: 'BFB6D2', pt: 0.5 } }); } }
  }
  s = p.addSlide(); base(s, 'Circuit de validation');
  const rows = [['Auteur', c.author.name, fmtDate(c.doc.submitted_at), 'Signé']].concat(c.approvals.map(a => [a.label || a.role, a.signer_name || a.assignee_name || '', fmtDate(a.signed_at), a.status === 'approved' ? 'Validé' : a.status === 'rejected' ? 'Retourné' : 'En attente']));
  s.addTable(rows.map((r, i) => r.map(v => ({ text: String(v), options: i === 0 ? {} : {} }))), { x: 0.5, y: 1.4, w: 12.3, fontSize: 13, border: { type: 'solid', color: 'BFB6D2', pt: 0.5 } });
  return Buffer.from(await p.write({ outputType: 'nodebuffer' }));
}

// ------------------------------------------------------------------ RAPPORTS (liste de documents / enquêtes / candidatures)
// table = { title, subtitle, headers:[], rows:[[]], summary:[[label,value]] , dept }
async function tableToXlsx(t) {
  const wb = new ExcelJS.Workbook(); wb.creator = 'RFAD ASBL'; const col = COLORS[t.dept] || COLORS.GEN;
  const ws = wb.addWorksheet('Rapport'); const lid = wb.addImage({ buffer: LOGO, extension: 'png' }); ws.addImage(lid, { tl: { col: 0, row: 0 }, ext: { width: 56, height: 56 } });
  ws.getCell('B1').value = ORG; ws.getCell('B1').font = { bold: true, size: 13, color: { argb: 'FF' + col } }; ws.getCell('B2').value = t.title; ws.getCell('B2').font = { bold: true, size: 12 }; ws.getCell('B3').value = t.subtitle || ''; ws.getRow(1).height = 22; ws.getRow(2).height = 22;
  let r = 5; (t.summary || []).forEach(([k, v]) => { ws.getCell(r, 1).value = k; ws.getCell(r, 1).font = { bold: true }; ws.getCell(r, 2).value = v; r++; }); r++;
  const hr = r; t.headers.forEach((h, j) => { const x = ws.getCell(r, j + 1); x.value = h; x.font = { bold: true, color: { argb: 'FFFFFFFF' } }; x.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + col } }; x.alignment = { wrapText: true }; }); r++;
  t.rows.forEach(row => { row.forEach((v, j) => { const x = ws.getCell(r, j + 1); x.value = (typeof v === 'string' && v !== '' && !isNaN(Number(v)) && v.trim() === v && v.length < 15 && !/^0\d/.test(v)) ? Number(v) : v; x.alignment = { wrapText: true, vertical: 'top' }; }); r++; });
  ws.columns.forEach((c, i) => { c.width = i === 0 ? 24 : Math.min(40, Math.max(14, ...t.rows.slice(0, 50).map(x => String(x[i] ?? '').length + 2), (t.headers[i] || '').length + 2)); });
  ws.views = [{ state: 'frozen', ySplit: hr }]; ws.autoFilter = { from: { row: hr, column: 1 }, to: { row: hr, column: t.headers.length } };
  return Buffer.from(await wb.xlsx.writeBuffer());
}
async function tableToDocx(t) {
  const col = COLORS[t.dept] || COLORS.GEN; const border = { style: D.BorderStyle.SINGLE, size: 4, color: 'BFB6D2' }; const borders = { top: border, bottom: border, left: border, right: border };
  const P = (x, o = {}) => new D.Paragraph({ spacing: { after: o.after ?? 60 }, children: [new D.TextRun({ text: String(x ?? ''), bold: o.bold, size: o.size || 18, color: o.color, font: 'Calibri' })] });
  const W = 15000, n = t.headers.length, w = Math.floor(W / n);
  const cell = (x, o = {}) => new D.TableCell({ borders, width: { size: w, type: D.WidthType.DXA }, shading: o.fill ? { type: D.ShadingType.CLEAR, color: 'auto', fill: o.fill } : undefined, margins: { top: 40, bottom: 40, left: 70, right: 70 }, children: [P(x, { size: 15, bold: o.bold, color: o.color, after: 0 })] });
  const kids = [P(t.title, { bold: true, size: 32, color: col }), P(t.subtitle || '', { color: '6B678A', size: 18, after: 120 })];
  if (t.summary && t.summary.length) kids.push(new D.Table({ width: { size: 6000, type: D.WidthType.DXA }, columnWidths: [3600, 2400], rows: t.summary.map(([k, v]) => new D.TableRow({ children: [new D.TableCell({ borders, width: { size: 3600, type: D.WidthType.DXA }, shading: { type: D.ShadingType.CLEAR, color: 'auto', fill: 'F1EBF7' }, children: [P(k, { bold: true, size: 17, after: 0 })] }), new D.TableCell({ borders, width: { size: 2400, type: D.WidthType.DXA }, children: [P(v, { size: 17, after: 0 })] })] })) }));
  kids.push(P('', { after: 120 }));
  kids.push(new D.Table({ width: { size: w * n, type: D.WidthType.DXA }, columnWidths: t.headers.map(() => w), rows: [new D.TableRow({ tableHeader: true, children: t.headers.map(h => cell(h, { fill: col, bold: true, color: 'FFFFFF' })) }), ...t.rows.map(r => new D.TableRow({ cantSplit: true, children: t.headers.map((h, j) => cell(r[j])) }))] }));
  const header = new D.Header({ children: [new D.Paragraph({ border: { bottom: { style: D.BorderStyle.SINGLE, size: 12, color: 'E8A317', space: 4 } }, children: [new D.ImageRun({ type: 'png', data: LOGO, transformation: { width: 44, height: 44 } }), new D.TextRun({ text: '   ' + ORG, bold: true, color: col, size: 20 })] })] });
  const footer = new D.Footer({ children: [P(`Généré le ${fmtDate(Date.now())} · RFAD ASBL`, { size: 14, color: '6B678A' })] });
  return D.Packer.toBuffer(new D.Document({ creator: 'RFAD ASBL', title: t.title, sections: [{ properties: { page: { size: { width: 16838, height: 11906 }, margin: { top: 1300, bottom: 800, left: 800, right: 800 } } }, headers: { default: header }, footers: { default: footer }, children: kids }] }));
}
async function tableToPptx(t) {
  const col = COLORS[t.dept] || COLORS.GEN; const p = new PptxGenJS(); p.layout = 'LAYOUT_WIDE'; p.author = 'RFAD ASBL'; p.title = t.title;
  const logo = 'data:image/png;base64,' + LOGO.toString('base64'), ec = 'data:image/png;base64,' + eclat(t.dept).toString('base64');
  let s = p.addSlide(); s.background = { color: col }; s.addImage({ data: logo, x: 0.6, y: 0.5, w: 1.4, h: 1.4 }); s.addText(t.title, { x: 0.6, y: 2.4, w: 12, h: 1.5, fontSize: 36, bold: true, color: 'FFFFFF' }); s.addText(t.subtitle || '', { x: 0.6, y: 4.1, w: 12, h: 0.8, fontSize: 18, color: 'FFFFFF' }); s.addText(ORG, { x: 0.6, y: 6.6, w: 12, h: 0.5, fontSize: 14, color: 'FFFFFF' });
  const base = (sl, title) => { sl.addImage({ data: ec, x: 10.4, y: -0.6, w: 3.6, h: 3.6, transparency: 70 }); sl.addImage({ data: logo, x: 0.4, y: 0.25, w: 0.8, h: 0.8 }); sl.addText(title, { x: 1.4, y: 0.3, w: 9, h: 0.7, fontSize: 22, bold: true, color: col }); sl.addShape(p.ShapeType.line, { x: 0.4, y: 1.15, w: 12.5, h: 0, line: { color: 'E8A317', width: 2 } }); };
  if (t.summary && t.summary.length) { s = p.addSlide(); base(s, 'Synthèse'); s.addTable(t.summary.map(([k, v]) => [{ text: k, options: { bold: true, color: col, fill: { color: 'F1EBF7' } } }, { text: String(v) }]), { x: 0.6, y: 1.5, w: 9, colW: [6, 3], fontSize: 16, border: { type: 'solid', color: 'BFB6D2', pt: 0.5 } }); }
  const cols = t.headers.slice(0, 6);
  chunk(t.rows, 9).forEach((part, i) => { s = p.addSlide(); base(s, t.title.slice(0, 50) + (i ? ' (suite)' : '')); s.addTable([cols.map(h => ({ text: h, options: { bold: true, color: 'FFFFFF', fill: { color: col } } }))].concat(part.map(r => cols.map((h, j) => ({ text: String(r[j] ?? '') })))), { x: 0.4, y: 1.4, w: 12.5, fontSize: 11, border: { type: 'solid', color: 'BFB6D2', pt: 0.5 } }); });
  return Buffer.from(await p.write({ outputType: 'nodebuffer' }));
}
function tableToCsv(t) { const esc = v => { v = String(v ?? ''); return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }; return '﻿' + [t.headers, ...t.rows].map(r => r.map(esc).join(';')).join('\r\n'); }

// ------------------------------------------------------------------ MODÈLES VIERGES (Word / Excel / PowerPoint)
const TEMPLATES = {
  lettre: { title: 'Lettre officielle', desc: 'Papier à en-tête RFAD pour courrier sortant', kind: 'docx' },
  note: { title: 'Note de service', desc: 'Note interne à en-tête RFAD', kind: 'docx' },
  pv: { title: 'Procès-verbal de réunion', desc: 'Trame OUT-ADM-02', kind: 'docx' },
  rapport: { title: 'Rapport (activité, mission, projet)', desc: 'Trame de rapport narratif', kind: 'docx' },
  registre: { title: 'Registre / suivi (Excel)', desc: 'Tableau de suivi avec filtres', kind: 'xlsx' },
  budget: { title: 'Budget de projet (Excel)', desc: 'Budget avec formules de totaux', kind: 'xlsx' },
  presentation: { title: 'Présentation RFAD (PowerPoint)', desc: 'Diapositives à l’identité RFAD', kind: 'pptx' },
  enquete: { title: 'Formulaire d’enquête (Word)', desc: 'Trame de questionnaire imprimable', kind: 'docx' },
  candidature: { title: 'Formulaire de candidature (Word)', desc: 'Dossier de candidature imprimable', kind: 'docx' },
};
async function template(name) {
  const col = COLORS.GEN; const T = TEMPLATES[name]; if (!T) return null;
  if (T.kind === 'xlsx') { const wb = new ExcelJS.Workbook(); const ws = wb.addWorksheet(T.title.replace(/[\\/?*:\[\]]/g, '-').slice(0, 28)); const lid = wb.addImage({ buffer: LOGO, extension: 'png' }); ws.addImage(lid, { tl: { col: 0, row: 0 }, ext: { width: 56, height: 56 } }); ws.getCell('B1').value = ORG; ws.getCell('B1').font = { bold: true, size: 13, color: { argb: 'FF5B2A86' } }; ws.getCell('B2').value = T.title; ws.getRow(1).height = 22;
    const hd = name === 'budget' ? ['Ligne budgétaire', 'Description', 'Unité', 'Quantité', 'Coût unitaire (USD)', 'Total (USD)'] : ['N°', 'Date', 'Libellé', 'Référence', 'Responsable', 'Statut', 'Observation'];
    hd.forEach((h, j) => { const x = ws.getCell(5, j + 1); x.value = h; x.font = { bold: true, color: { argb: 'FFFFFFFF' } }; x.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF5B2A86' } }; ws.getColumn(j + 1).width = j === 1 || j === 2 ? 34 : 18; });
    for (let i = 6; i < 36; i++) { if (name === 'budget') { ws.getCell(i, 6).value = { formula: `D${i}*E${i}` }; ws.getCell(i, 6).numFmt = '#,##0.00'; } hd.forEach((h, j) => ws.getCell(i, j + 1).border = { bottom: { style: 'hair' } }); }
    if (name === 'budget') { ws.getCell('E37').value = 'TOTAL'; ws.getCell('E37').font = { bold: true }; ws.getCell('F37').value = { formula: 'SUM(F6:F35)' }; ws.getCell('F37').font = { bold: true }; ws.getCell('F37').numFmt = '#,##0.00'; }
    ws.views = [{ state: 'frozen', ySplit: 5 }]; ws.autoFilter = { from: 'A5', to: String.fromCharCode(64 + hd.length) + '5' }; return Buffer.from(await wb.xlsx.writeBuffer()); }
  if (T.kind === 'pptx') { const p = new PptxGenJS(); p.layout = 'LAYOUT_WIDE'; const logo = 'data:image/png;base64,' + LOGO.toString('base64'), ec = 'data:image/png;base64,' + eclat('GEN').toString('base64');
    let s = p.addSlide(); s.background = { color: '5B2A86' }; s.addImage({ data: logo, x: 0.6, y: 0.5, w: 1.4, h: 1.4 }); s.addText('Titre de la présentation', { x: 0.6, y: 2.6, w: 12, h: 1.4, fontSize: 40, bold: true, color: 'FFFFFF' }); s.addText('Sous-titre · date · auteur', { x: 0.6, y: 4.2, w: 12, h: 0.6, fontSize: 18, color: 'FFFFFF' }); s.addText(ORG, { x: 0.6, y: 6.6, w: 12, h: 0.5, fontSize: 14, color: 'FFFFFF' });
    ['Contexte et objectifs', 'Activités et résultats', 'Défis et leçons apprises', 'Prochaines étapes'].forEach(t => { s = p.addSlide(); s.addImage({ data: ec, x: 10.4, y: -0.6, w: 3.6, h: 3.6, transparency: 70 }); s.addImage({ data: logo, x: 0.4, y: 0.25, w: 0.8, h: 0.8 }); s.addText(t, { x: 1.4, y: 0.3, w: 9, h: 0.7, fontSize: 26, bold: true, color: '5B2A86' }); s.addShape(p.ShapeType.line, { x: 0.4, y: 1.15, w: 12.5, h: 0, line: { color: 'E8A317', width: 2 } }); s.addText([{ text: 'Point clé 1', options: { bullet: true } }, { text: 'Point clé 2', options: { bullet: true } }, { text: 'Point clé 3', options: { bullet: true } }], { x: 0.8, y: 1.6, w: 11.5, h: 4.5, fontSize: 22 }); });
    return Buffer.from(await p.write({ outputType: 'nodebuffer' })); }
  // docx
  const P = (t, o = {}) => new D.Paragraph({ spacing: { after: o.after ?? 120 }, alignment: o.align, children: [new D.TextRun({ text: t, bold: o.bold, size: o.size || 22, color: o.color, font: 'Calibri', italics: o.italics })] });
  const lines = n => Array.from({ length: n }, () => P('………………………………………………………………………………………………………………………………………………', { color: 'AAAAAA' }));
  let body = [];
  if (name === 'lettre') body = [P('N° : RFAD/…/…/2026', { size: 20 }), P('Beni, le …………………', { align: D.AlignmentType.RIGHT }), P('À l’attention de : ……………………………', { bold: true }), P('Objet : ……………………………', { bold: true }), P('Madame, Monsieur,'), ...lines(8), P('Veuillez agréer, Madame, Monsieur, l’expression de nos salutations distinguées.'), P(''), P('Le Directeur exécutif', { bold: true }), P('(nom, signature et cachet)', { italics: true, color: '6B678A' })];
  else if (name === 'note') body = [P('NOTE DE SERVICE N° …/2026', { bold: true, size: 30, color: col }), P('De : ………………… À : ………………… Date : …………………'), P('Objet : …………………', { bold: true }), P('Contexte', { bold: true, color: col }), ...lines(3), P('Dispositions', { bold: true, color: col }), ...lines(5), P('Entrée en vigueur : …………………')];
  else if (name === 'pv') body = [P('PROCÈS-VERBAL DE RÉUNION', { bold: true, size: 30, color: col }), P('Type : ………… Date : ………… Lieu : ………… Heure : ………… à …………'), P('Président(e) de séance : ………… Secrétaire : …………'), P('Participants', { bold: true, color: col }), ...lines(3), P('Ordre du jour', { bold: true, color: col }), ...lines(2), P('Délibérations', { bold: true, color: col }), ...lines(5), P('Décisions et actions (qui, quoi, quand)', { bold: true, color: col }), ...lines(4), P('Signatures : Président(e) ………………   Secrétaire ………………')];
  else if (name === 'rapport') body = [P('RAPPORT DE ……………', { bold: true, size: 30, color: col }), P('Période : ………… Auteur : ………… Projet : …………'), ...['1. Résumé', '2. Contexte et objectifs', '3. Activités réalisées', '4. Résultats et indicateurs', '5. Difficultés et leçons apprises', '6. Recommandations et prochaines étapes'].flatMap(h => [P(h, { bold: true, color: col, size: 24 }), ...lines(3)])];
  else if (name === 'enquete') body = [P('FORMULAIRE D’ENQUÊTE', { bold: true, size: 30, color: col }), P('Enquête : ………… Date : ………… Lieu : ………… Enquêteur : …………'), P('Consentement : la personne a été informée du but de l’enquête et accepte d’y participer librement.  ☐ Oui  ☐ Non', { italics: true }), ...[1, 2, 3, 4, 5, 6].flatMap(i => [P(`Q${i}. ……………………………………………………………  ☐ Oui  ☐ Non  ☐ Ne sait pas`, { bold: true }), P('Commentaire : ………………………………………………………………', { color: '777777' })])];
  else body = [P('FORMULAIRE DE CANDIDATURE', { bold: true, size: 30, color: col }), P('Poste : ………… Référence : ………… Lieu : …………'), ...['Nom et prénom', 'Sexe / date et lieu de naissance', 'Adresse, téléphone, courriel', 'Diplôme le plus élevé', 'Expérience professionnelle (3 dernières)', 'Langues parlées et écrites', 'Références (2 personnes)', 'Motivation (5 lignes)'].map(l => P(l + ' : …………………………………………………………………………', { size: 22 })), P('Documents à joindre : lettre de motivation, CV, copies des diplômes. Aucune somme n’est exigée pour le recrutement.', { italics: true, color: '6B678A' }), P('Je certifie l’exactitude des informations. Date et signature : …………')];
  const header = new D.Header({ children: [new D.Paragraph({ border: { bottom: { style: D.BorderStyle.SINGLE, size: 12, color: 'E8A317', space: 4 } }, children: [new D.ImageRun({ type: 'png', data: LOGO, transformation: { width: 56, height: 56 } }), new D.TextRun({ text: '   ' + ORG, bold: true, color: col, size: 22 })] })] });
  const footer = new D.Footer({ children: [P('RFAD ASBL · Beni, Nord-Kivu, RDC · rfad-asbl.org', { size: 16, color: '6B678A', align: D.AlignmentType.CENTER })] });
  return D.Packer.toBuffer(new D.Document({ creator: 'RFAD ASBL', title: T.title, sections: [{ properties: { page: { margin: { top: 1500, bottom: 1000, left: 1200, right: 1200 } } }, headers: { default: header }, footers: { default: footer }, children: body }] }));
}
module.exports = { docToDocx, docToXlsx, docToPptx, tableToXlsx, tableToDocx, tableToPptx, tableToCsv, template, TEMPLATES, normalize, STATUS, fmtDate, COLORS };
