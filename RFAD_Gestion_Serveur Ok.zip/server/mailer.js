'use strict';
// File d'attente d'e-mails (SMTP). Sans configuration SMTP, les messages restent en attente et partent dès que l'envoi est configuré.
const nodemailer = require('nodemailer');
const { run, get, all, now, setting, setSetting } = require('./db');
const DEFAULT_ADMIN_EMAIL = process.env.RFAD_ADMIN_EMAIL || 'rfad.rdc@gmail.com';
function smtpConf() {
  const s = setting('smtp', {}) || {};
  const c = { host: s.host || process.env.RFAD_SMTP_HOST || '', port: Number(s.port || process.env.RFAD_SMTP_PORT || 465), secure: s.secure != null ? !!s.secure : (process.env.RFAD_SMTP_SECURE || '1') === '1',
    user: s.user || process.env.RFAD_SMTP_USER || '', pass: s.pass || process.env.RFAD_SMTP_PASS || '', from: s.from || process.env.RFAD_SMTP_FROM || '' };
  if (!c.from) c.from = c.user ? `RFAD Gestion <${c.user}>` : 'RFAD Gestion <rfad.rdc@gmail.com>';
  return c;
}
const configured = () => !!smtpConf().host;
function adminEmail() { return setting('admin_email', DEFAULT_ADMIN_EMAIL) || DEFAULT_ADMIN_EMAIL; }
function baseUrl() { return setting('base_url', process.env.RFAD_BASE_URL || ''); }
function queue(to, subject, text) { if (!to || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) return; run("INSERT INTO outbox(to_addr,subject,body,status,tries,at) VALUES(?,?,?,'pending',0,?)", to, String(subject).slice(0, 200), String(text).slice(0, 8000), now()); setImmediate(() => flush().catch(() => {})); }
let busy = false;
async function transport() { const c = smtpConf(); return nodemailer.createTransport({ host: c.host, port: c.port, secure: c.secure, auth: c.user ? { user: c.user, pass: c.pass } : undefined, connectionTimeout: 15000, greetingTimeout: 15000, socketTimeout: 20000, tls: { rejectUnauthorized: process.env.RFAD_SMTP_INSECURE_TLS !== '1' } }); }
async function flush() {
  if (busy || !configured()) return; busy = true;
  try { const rows = all("SELECT * FROM outbox WHERE status='pending' AND tries<8 ORDER BY id LIMIT 20"); if (!rows.length) return; const t = await transport(); const c = smtpConf();
    for (const m of rows) { try { await t.sendMail({ from: c.from, to: m.to_addr, subject: m.subject, text: m.body }); run("UPDATE outbox SET status='sent', sent_at=?, error='' WHERE id=?", now(), m.id); }
      catch (e) { run("UPDATE outbox SET tries=tries+1, error=?, status=CASE WHEN tries+1>=8 THEN 'failed' ELSE 'pending' END WHERE id=?", String(e.message).slice(0, 300), m.id); } } }
  finally { busy = false; }
}
async function test(to) { const t = await transport(); const c = smtpConf(); await t.sendMail({ from: c.from, to, subject: 'RFAD Gestion – test d’envoi', text: 'Ce message confirme que l’envoi d’e-mails de RFAD Gestion fonctionne.' }); }
setInterval(() => flush().catch(() => {}), 120000).unref();
module.exports = { queue, flush, test, configured, smtpConf, adminEmail, baseUrl, DEFAULT_ADMIN_EMAIL, setSetting };
