'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const DB = require('./db'); const { run, get, all, now, tx, audit, notify, setting, setSetting } = DB;
const M = require('./mailer'); const A = require('./auth'); const R = require('./roles'); const X = require('./exports');
const FORMS = require('./forms.json'); const TOC = JSON.parse(fs.readFileSync(path.join(__dirname, 'toc.json'), 'utf8'));
const PORT = Number(process.env.RFAD_PORT || process.env.PORT || 8080), HOST = process.env.RFAD_HOST || '0.0.0.0';
const PUBDIR = path.join(__dirname, '..', 'public'); const UP = path.join(DB.DATA, 'uploads');
const TRUST = process.env.RFAD_TRUST_PROXY === '1';
const ALLOWED_EXT = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'png', 'jpg', 'jpeg', 'txt', 'csv', 'odt', 'ods', 'zip'];
const MIME = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', json: 'application/json; charset=utf-8', png: 'image/png', jpg: 'image/jpeg', ico: 'image/x-icon', svg: 'image/svg+xml', webmanifest: 'application/manifest+json', pdf: 'application/pdf', txt: 'text/plain; charset=utf-8' };
const OFFICE = { docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', csv: 'text/csv; charset=utf-8' };
const DEPTS = { ADM: 'Administration', RH: 'Ressources humaines', FIN: 'Finances', CPT: 'Comptabilité', LOG: 'Logistique, approvisionnements, transports et achats', SEC: 'Sécurité et sauvegarde' };

class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const bad = (m) => new HttpError(400, m), forbid = (m) => new HttpError(403, m || 'Accès refusé.'), nf = (m) => new HttpError(404, m || 'Introuvable.');
const J = s => { try { return JSON.parse(s); } catch (e) { return null; } };
const params = () => setting('params', R.DEFAULT_PARAMS);
const roleLabel = r => (R.ROLES[r] || {}).label || r;
const str = (v, max = 300) => (v == null ? '' : String(v)).slice(0, max);
const isMgr = u => ['ADMIN', 'DE', 'COORD'].includes(u.role);

// ---------------------------------------------------------------- amorçage
function bootstrap() {
  if (!get('SELECT id FROM users LIMIT 1')) {
    const given = process.env.RFAD_ADMIN_PASSWORD; const email = M.DEFAULT_ADMIN_EMAIL;
    const pwd = given || crypto.randomBytes(9).toString('base64url') + '7a'; const h = A.hashPwd(pwd);
    run("INSERT INTO users(username,name,email,salt,hash,role,dept,post,status,must_change,created_at,approved_at) VALUES('admin','Administrateur RFAD',?,?,?,'ADMIN',NULL,'Administrateur système','active',1,?,?)", email, h.salt, h.hash, now(), now());
    const f = path.join(DB.DATA, 'ADMIN_INITIAL.txt');
    fs.writeFileSync(f, `Compte administrateur principal RFAD\nConnexion : ${email}  (ou nom d'utilisateur : admin)\n` + (given ? 'Mot de passe : celui défini à l\'installation (RFAD_ADMIN_PASSWORD, fichier config) – changement obligatoire à la première connexion.\n' : `Mot de passe temporaire : ${pwd}\n`) + '(supprimez ce fichier après la première connexion)\n', { mode: 0o600 });
    console.log('\n=== PREMIER DÉMARRAGE ===\nAdministrateur : ' + email + ' (ou admin)\n' + (given ? 'Mot de passe : défini par RFAD_ADMIN_PASSWORD' : 'Mot de passe temporaire : ' + pwd) + '\nFichier : ' + f + '\n=========================\n');
  }
  // Synchronise le compte principal tant que son mot de passe initial n'a pas été changé (réinstallation, base existante)
  const adm = get("SELECT * FROM users WHERE username='admin'"); const g = process.env.RFAD_ADMIN_PASSWORD; const em = (process.env.RFAD_ADMIN_EMAIL || M.DEFAULT_ADMIN_EMAIL).toLowerCase();
  if (adm) {
    if (!adm.email || String(adm.email).toLowerCase() !== em) run('UPDATE users SET email=? WHERE id=?', em, adm.id);
    if (g && (adm.must_change || process.env.RFAD_ADMIN_RESET === '1') && !A.checkPwd(g, adm.salt, adm.hash)) {
      const h = A.hashPwd(g); run("UPDATE users SET salt=?,hash=?,must_change=1,status='active',failed=0,locked_until=0 WHERE id=?", h.salt, h.hash, adm.id); console.log('Compte administrateur : mot de passe initial synchronisé avec RFAD_ADMIN_PASSWORD.');
    } else if (adm.status !== 'active' || adm.locked_until > now()) run("UPDATE users SET status='active',failed=0,locked_until=0 WHERE id=?", adm.id);
  }
  if (!get("SELECT v FROM settings WHERE k='params'")) setSetting('params', R.DEFAULT_PARAMS);
  if (!get("SELECT v FROM settings WHERE k='admin_email'")) setSetting('admin_email', M.DEFAULT_ADMIN_EMAIL);
}
bootstrap();

// ---------------------------------------------------------------- utilitaires HTTP
function parseCookies(h) { const o = {}; (h || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); }); return o; }
function readBody(req, limit = 14 * 1024 * 1024) { return new Promise((res, rej) => { const ch = []; let n = 0; req.on('data', d => { n += d.length; if (n > limit) { rej(new HttpError(413, 'Fichier ou requête trop volumineux.')); req.destroy(); } else ch.push(d); }); req.on('end', () => { if (!ch.length) return res({}); try { res(JSON.parse(Buffer.concat(ch).toString('utf8'))); } catch (e) { rej(bad('JSON invalide.')); } }); req.on('error', rej); }); }
function secHeaders(res, secure) {
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'DENY'); res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-src 'self'; object-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()'); if (secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
}
const clientIp = req => (TRUST && req.headers['x-forwarded-for']) ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress;

// ---------------------------------------------------------------- accès aux documents
function docRow(id) { const d = get('SELECT * FROM docs WHERE id=?', id); if (!d) throw nf('Document introuvable.'); return d; }
function canSee(u, d) {
  if (d.author_id === u.id || R.canViewAll(u)) return true;
  if (get('SELECT 1 x FROM approvals WHERE doc_id=? AND assignee_id=?', d.id, u.id)) return true;
  return R.viewDepts(u).includes(d.dept);
}
function currentRound(id) { const r = get('SELECT MAX(round) m FROM approvals WHERE doc_id=?', id); return r && r.m || 0; }
function loadApprovals(id) {
  const rd = currentRound(id);
  return all('SELECT a.*, u.name assignee_name, u.post assignee_post FROM approvals a LEFT JOIN users u ON u.id=a.assignee_id WHERE a.doc_id=? AND a.round=? ORDER BY a.step', id, rd);
}
function ctxFor(d) {
  const form = FORMS.forms[d.code]; const author = get('SELECT id,name,post,role,dept FROM users WHERE id=?', d.author_id) || { name: '?' };
  const ap = loadApprovals(d.id); const authorSig = ap.find(a => a.step === 0) || null;
  return { doc: d, form, data: J(d.data) || {}, author, approvals: ap.filter(a => a.step > 0), authorSig };
}
function makeRef(code) {
  const y = new Date().getFullYear(), s = R.short(code);
  let n = (get('SELECT COUNT(*) c FROM docs WHERE code=? AND ref LIKE ?', code, `RFAD/${s}/${y}/%`).c) + 1;
  while (get('SELECT 1 x FROM docs WHERE ref=?', `RFAD/${s}/${y}/${String(n).padStart(4, '0')}`)) n++;
  return `RFAD/${s}/${y}/${String(n).padStart(4, '0')}`;
}
function cleanData(d) { if (!d || typeof d !== 'object') return { blocks: [] }; const s = JSON.stringify(d); if (s.length > 1.5e6) throw bad('Données trop volumineuses.'); return d; }
function candidates(role, exclude) {
  let rows;
  if (role === 'RESP' || role === 'ANY') rows = all("SELECT id,name,post,role FROM users WHERE status='active' AND role!='ADMIN' AND id!=? ORDER BY name", exclude || 0);
  else rows = all("SELECT id,name,post,role FROM users WHERE status='active' AND (role=? OR role='ADMIN' AND ?='ADMIN') AND id!=? ORDER BY name", role, role, exclude || 0);
  return rows;
}
function snapshot(d, userId, reason) { run('INSERT INTO doc_versions(doc_id,version,data,title,amount,by_user,reason,at) VALUES(?,?,?,?,?,?,?,?)', d.id, d.version, d.data, d.title, d.amount, userId, reason || '', now()); }
function sigHash(d, userId, t) { return A.sha(`${d.id}|${d.version}|${d.data}|${d.amount}|${userId}|${t}`); }
function validSig(s) { if (!s) return null; if (typeof s !== 'string' || !/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(s) || s.length > 150000) throw bad('Signature invalide.'); return s; }

// ---------------------------------------------------------------- tableaux de rapport
function visibleDocsSQL(u) {
  if (R.canViewAll(u)) return { where: '1=1', p: [] };
  const depts = R.viewDepts(u); const ph = depts.map(() => '?').join(',');
  return { where: `(d.author_id=? OR d.id IN (SELECT doc_id FROM approvals WHERE assignee_id=?)${depts.length ? ` OR d.dept IN (${ph})` : ''})`, p: [u.id, u.id, ...depts] };
}
function reportTable(u, q) {
  const type = q.type || 'docs'; const from = q.from ? new Date(q.from + 'T00:00:00').getTime() : 0, to = q.to ? new Date(q.to + 'T23:59:59').getTime() : 9e15;
  const per = (q.from || q.to) ? `Période : ${q.from || '…'} → ${q.to || '…'}` : 'Toute la période';
  if (type === 'docs') {
    const v = visibleDocsSQL(u); let w = v.where + ' AND d.created_at BETWEEN ? AND ?'; const p = [...v.p, from, to];
    if (q.dept && DEPTS[q.dept]) { w += ' AND d.dept=?'; p.push(q.dept); } if (q.status) { w += ' AND d.status=?'; p.push(q.status); } if (q.code) { w += ' AND d.code=?'; p.push(q.code); }
    const rows = all(`SELECT d.*, u.name author FROM docs d JOIN users u ON u.id=d.author_id WHERE ${w} ORDER BY d.created_at DESC LIMIT 5000`, ...p);
    const by = {}; rows.forEach(r => { by[r.status] = (by[r.status] || 0) + 1; });
    return { title: 'Rapport des documents de gestion', subtitle: per + (q.dept ? ' · ' + DEPTS[q.dept] : ''), dept: q.dept || 'GEN',
      summary: [['Documents', rows.length], ...Object.keys(by).map(k => [X.STATUS[k] || k, by[k]]), ['Montant cumulé (USD)', rows.reduce((s, r) => s + (r.amount || 0), 0)]],
      headers: ['Référence', 'Outil', 'Objet', 'Département', 'Auteur', 'Statut', 'Montant (USD)', 'Créé le', 'Mis à jour'], rows: rows.map(r => [r.ref, r.code, r.title || (FORMS.forms[r.code] || {}).title, DEPTS[r.dept] || r.dept, r.author, X.STATUS[r.status], r.amount || '', X.fmtDate(r.created_at), X.fmtDate(r.updated_at)]) };
  }
  if (type === 'validations') {
    const v = visibleDocsSQL(u); const rows = all(`SELECT a.*, d.ref, d.title, d.code, u2.name aname FROM approvals a JOIN docs d ON d.id=a.doc_id LEFT JOIN users u2 ON u2.id=a.assignee_id WHERE a.step>0 AND a.round=(SELECT MAX(round) FROM approvals WHERE doc_id=a.doc_id) AND ${v.where} ORDER BY d.updated_at DESC LIMIT 5000`, ...v.p);
    return { title: 'Suivi des validations', subtitle: per, dept: 'GEN', summary: [['Étapes', rows.length], ['En attente de signature', rows.filter(r => r.status === 'pending').length]], headers: ['Référence', 'Objet', 'Étape', 'Validateur', 'Statut', 'Date de signature'], rows: rows.map(r => [r.ref, r.title || r.code, r.label || roleLabel(r.role), r.aname, r.status === 'approved' ? 'Validé' : r.status === 'pending' ? 'À signer' : r.status === 'rejected' ? 'Retourné' : r.status === 'waiting' ? 'En attente' : r.status, X.fmtDate(r.signed_at)]) };
  }
  if (type === 'tasks') {
    const mgr = isMgr(u); const rows = all(`SELECT t.*, a.name aname, c.name cname FROM tasks t LEFT JOIN users a ON a.id=t.assignee_id LEFT JOIN users c ON c.id=t.created_by WHERE ${mgr ? '1=1' : '(t.assignee_id=? OR t.created_by=?)'} AND t.created_at BETWEEN ? AND ? ORDER BY t.created_at DESC LIMIT 5000`, ...(mgr ? [] : [u.id, u.id]), from, to);
    return { title: 'Rapport des tâches et responsabilités', subtitle: per, dept: 'GEN', summary: [['Tâches', rows.length], ['Terminées', rows.filter(r => r.status === 'done').length], ['Ouvertes', rows.filter(r => r.status !== 'done').length]], headers: ['Tâche', 'Assignée à', 'Créée par', 'Échéance', 'Statut', 'Procédure', 'Description'], rows: rows.map(r => [r.title, r.aname, r.cname, r.due, r.status === 'done' ? 'Terminée' : 'Ouverte', r.procedure_ref, r.description]) };
  }
  if (type === 'apps') {
    if (!['ADMIN', 'DE', 'COORD', 'RH'].includes(u.role)) throw forbid();
    const rows = all('SELECT a.*, j.title jt, j.ref jr FROM applications a LEFT JOIN jobs j ON j.id=a.job_id WHERE a.at BETWEEN ? AND ? ORDER BY a.at DESC', from, to);
    return { title: 'Rapport des candidatures', subtitle: per, dept: 'RH', summary: [['Candidatures', rows.length], ['Retenues', rows.filter(r => r.status === 'shortlisted').length]], headers: ['Poste', 'Nom', 'Sexe', 'Téléphone', 'Courriel', 'Diplôme', 'Statut', 'Note', 'Reçue le'], rows: rows.map(r => { const d = J(r.data) || {}; return [r.jt, d.name, d.sex, d.phone, d.email, d.diploma, APP_ST[r.status] || r.status, r.score ?? '', X.fmtDate(r.at)]; }) };
  }
  if (type === 'users') {
    if (u.role !== 'ADMIN') throw forbid(); const rows = all('SELECT * FROM users ORDER BY name');
    return { title: 'Rapport des comptes et responsabilités', subtitle: per, dept: 'GEN', summary: [['Comptes', rows.length], ['Actifs', rows.filter(r => r.status === 'active').length], ['En attente', rows.filter(r => r.status === 'pending').length]], headers: ['Nom', 'Utilisateur', 'Rôle', 'Département', 'Poste', 'Statut', 'Responsabilités', 'Dernière connexion'], rows: rows.map(r => [r.name, r.username, roleLabel(r.role), DEPTS[r.dept] || r.dept || '', r.post, r.status, r.responsibilities, X.fmtDate(r.last_login)]) };
  }
  if (type === 'audit') {
    if (!['ADMIN', 'CC'].includes(u.role)) throw forbid(); const rows = all('SELECT * FROM audit WHERE at BETWEEN ? AND ? ORDER BY at DESC LIMIT 5000', from, to);
    return { title: 'Journal d’audit', subtitle: per, dept: 'GEN', summary: [['Événements', rows.length]], headers: ['Date', 'Utilisateur', 'Action', 'Cible', 'Détail', 'IP'], rows: rows.map(r => [X.fmtDate(r.at), r.username, r.action, r.target, r.detail, r.ip]) };
  }
  if (type === 'survey') {
    const s = get('SELECT * FROM surveys WHERE id=?', Number(q.id)); if (!s) throw nf(); const sc = J(s.schema) || { questions: [] };
    const rs = all('SELECT * FROM survey_responses WHERE survey_id=? ORDER BY at', s.id);
    const hs = ['Date', ...sc.questions.map(x => x.label)];
    const rows = rs.map(r => { const d = J(r.data) || {}; return [X.fmtDate(r.at), ...sc.questions.map(x => Array.isArray(d[x.id]) ? d[x.id].join(', ') : (d[x.id] ?? ''))]; });
    const summ = [['Réponses', rs.length]];
    sc.questions.filter(x => ['choice', 'multi'].includes(x.type)).forEach(x => { (x.options || []).forEach(o => { summ.push([`${x.label} – ${o}`, rs.filter(r => { const v = (J(r.data) || {})[x.id]; return Array.isArray(v) ? v.includes(o) : v === o; }).length]); }); });
    return { title: 'Enquête : ' + s.title, subtitle: per, dept: 'GEN', summary: summ, headers: hs, rows };
  }
  throw bad('Type de rapport inconnu.');
}
const APP_ST = { new: 'Nouvelle', reviewed: 'Examinée', shortlisted: 'Présélectionnée', interview: 'Entretien', hired: 'Retenue', rejected: 'Non retenue' };
async function sendTable(res, t, fmt, fname) {
  if (fmt === 'json') return json(res, 200, t);
  if (fmt === 'xlsx') return buf(res, await X.tableToXlsx(t), OFFICE.xlsx, fname + '.xlsx');
  if (fmt === 'docx') return buf(res, await X.tableToDocx(t), OFFICE.docx, fname + '.docx');
  if (fmt === 'pptx') return buf(res, await X.tableToPptx(t), OFFICE.pptx, fname + '.pptx');
  if (fmt === 'csv') return buf(res, Buffer.from(X.tableToCsv(t), 'utf8'), OFFICE.csv, fname + '.csv');
  throw bad('Format inconnu.');
}
function json(res, code, obj) { const b = Buffer.from(JSON.stringify(obj)); res.writeHead(code, { 'Content-Type': MIME.json, 'Content-Length': b.length, 'Cache-Control': 'no-store' }); res.end(b); }
function buf(res, b, type, name) { res.writeHead(200, { 'Content-Type': type, 'Content-Length': b.length, 'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(name)}`, 'Cache-Control': 'no-store' }); res.end(b); }

// ---------------------------------------------------------------- routes API
const routes = [];
const route = (m, re, auth, fn) => routes.push({ m, re: new RegExp('^' + re + '$'), auth, fn });

// ---- public
route('GET', '/api/public/info', false, async () => ({ org: 'RFAD ASBL', name: 'Réseau des Femmes pour l’Aide et le Développement', jobs: all("SELECT id FROM jobs WHERE status='open'").length }));
route('POST', '/api/register', false, async c => {
  if (!A.rate('reg:' + c.ip, Number(process.env.RFAD_REG_LIMIT || 5), 3600e3)) throw new HttpError(429, 'Trop de demandes. Réessayez plus tard.');
  const b = c.body; const un = str(b.username, 30).toLowerCase().trim();
  if (!/^[a-z0-9._-]{3,30}$/.test(un)) throw bad('Nom d’utilisateur : 3 à 30 caractères (lettres minuscules, chiffres, . _ -).');
  if (!str(b.name, 100).trim()) throw bad('Nom complet requis.'); const pe = A.pwdPolicy(b.password, un); if (pe) throw bad(pe);
  if (b.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(b.email)) throw bad('Courriel invalide.');
  if (get('SELECT 1 x FROM users WHERE username=?', un)) throw bad('Ce nom d’utilisateur existe déjà.');
  const h = A.hashPwd(b.password);
  const r = run("INSERT INTO users(username,name,email,phone,salt,hash,status,requested_post,dept,message,created_at) VALUES(?,?,?,?,?,?,'pending',?,?,?,?)", un, str(b.name, 100).trim(), str(b.email, 120), str(b.phone, 40), h.salt, h.hash, str(b.requested_post, 120), DEPTS[b.dept] ? b.dept : null, str(b.message, 600), now());
  all("SELECT id FROM users WHERE role='ADMIN' AND status='active'").forEach(a => notify(a.id, `Nouvelle demande d’accès : ${str(b.name, 60)} (${un})`, '#/admin'));
  const dn = str(b.name, 100).trim(); const link = (M.baseUrl() || '') + '/#/admin/demandes';
  const rcpt = new Set([M.adminEmail(), ...all("SELECT email FROM users WHERE role='ADMIN' AND status='active' AND email!=''").map(x => x.email)]);
  rcpt.forEach(to => M.queue(to, 'RFAD Gestion – nouvelle demande d’accès : ' + dn, `Une nouvelle demande d’accès à RFAD Gestion attend votre validation.\n\nNom : ${dn}\nNom d’utilisateur : ${un}\nE-mail : ${str(b.email, 120) || '—'}\nTéléphone : ${str(b.phone, 40) || '—'}\nPoste demandé : ${str(b.requested_post, 120) || '—'}\nDépartement : ${DEPTS[b.dept] || '—'}\nMotif : ${str(b.message, 300) || '—'}\n\nConnectez-vous en tant qu’administrateur puis ouvrez Administration › Demandes d’accès pour attribuer le rôle, les responsabilités et valider ou refuser la demande.\n${link}\n\nRFAD ASBL – Beni, Nord-Kivu, RDC`));
  audit(null, 'register', un, 'demande d’accès', c.ip);
  return { ok: true, message: 'Votre demande a été enregistrée. Elle doit être validée par l’administrateur avant toute connexion.' };
});
route('POST', '/api/login', false, async c => {
  if (!A.rate('login:' + c.ip, Number(process.env.RFAD_LOGIN_LIMIT || 15), 600e3)) throw new HttpError(429, 'Trop de tentatives. Patientez quelques minutes.');
  const un = str(c.body.username, 80).toLowerCase().trim(); let u = get('SELECT * FROM users WHERE username=?', un);
  if (!u && un.includes('@')) { const m = all("SELECT * FROM users WHERE LOWER(email)=? AND status!='rejected'", un); if (m.length === 1) u = m[0]; }
  const generic = new HttpError(401, 'Nom d’utilisateur ou mot de passe incorrect.');
  if (!u) { A.hashPwd('x'); throw generic; }
  if (u.locked_until > now()) throw new HttpError(423, 'Compte temporairement verrouillé après plusieurs échecs. Réessayez dans quelques minutes.');
  if (!A.checkPwd(String(c.body.password || ''), u.salt, u.hash)) { const f = u.failed + 1; run('UPDATE users SET failed=?, locked_until=? WHERE id=?', f >= 5 ? 0 : f, f >= 5 ? now() + 15 * 60e3 : 0, u.id); audit(null, 'login_fail', un, '', c.ip); throw generic; }
  if (u.status === 'pending') throw new HttpError(403, 'Votre demande d’accès est en attente de validation par l’administrateur.');
  if (u.status === 'rejected') throw new HttpError(403, 'Votre demande d’accès a été refusée. Contactez l’administrateur.');
  if (u.status !== 'active') throw new HttpError(403, 'Compte suspendu. Contactez l’administrateur.');
  run('UPDATE users SET failed=0, locked_until=0, last_login=? WHERE id=?', now(), u.id);
  const sid = A.createSession(u.id, c.ip, c.req.headers['user-agent']); audit(u, 'login', u.username, '', c.ip);
  c.setCookie = `rfad_sid=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=36000${c.secure ? '; Secure' : ''}`;
  return { ok: true, must_change: !!u.must_change };
});
route('POST', '/api/logout', false, async c => { A.destroySession(c.sid); c.setCookie = 'rfad_sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'; return { ok: true }; });
route('GET', '/api/public/jobs', false, async () => all("SELECT id,ref,title,dept,location,contract,description,profile,deadline FROM jobs WHERE status='open' AND (deadline IS NULL OR deadline='' OR deadline>=?) ORDER BY created_at DESC", new Date().toISOString().slice(0, 10)));
function saveFile(name, b64) {
  const ext = (name.split('.').pop() || '').toLowerCase(); if (!ALLOWED_EXT.includes(ext)) throw bad('Type de fichier non autorisé (' + ext + ').');
  const data = Buffer.from(String(b64).replace(/^data:[^,]*,/, ''), 'base64'); if (data.length > 8 * 1024 * 1024) throw bad('Fichier trop volumineux (8 Mo maximum).'); if (!data.length) throw bad('Fichier vide.');
  const fn = crypto.randomBytes(16).toString('hex') + '.' + ext; fs.writeFileSync(path.join(UP, fn), data); return { file: fn, size: data.length, ext };
}
route('POST', '/api/public/apply', false, async c => {
  if (!A.rate('apply:' + c.ip, 8, 3600e3)) throw new HttpError(429, 'Trop de candidatures depuis cette adresse.');
  const job = get("SELECT * FROM jobs WHERE id=? AND status='open'", Number(c.body.job_id)); if (!job) throw bad('Offre introuvable ou clôturée.');
  const d = c.body.data || {}; if (!str(d.name).trim() || !str(d.phone).trim() && !str(d.email).trim()) throw bad('Nom et un moyen de contact (téléphone ou courriel) sont obligatoires.');
  const clean = {}; ['name', 'sex', 'birth', 'nationality', 'address', 'phone', 'email', 'diploma', 'experience', 'languages', 'references', 'motivation'].forEach(k => clean[k] = str(d[k], k === 'motivation' || k === 'experience' || k === 'references' ? 4000 : 300));
  clean.files = (Array.isArray(c.body.files) ? c.body.files : []).slice(0, 4).map(f => { const s = saveFile(str(f.name, 120), f.data); return { name: str(f.name, 120), file: s.file, size: s.size }; });
  const r = run('INSERT INTO applications(job_id,data,at,ip) VALUES(?,?,?,?)', job.id, JSON.stringify(clean), now(), c.ip);
  all("SELECT id FROM users WHERE role IN ('RH','ADMIN') AND status='active'").forEach(a => notify(a.id, `Nouvelle candidature : ${clean.name} – ${job.title}`, '#/recrutement'));
  audit(null, 'apply', job.ref || job.id, clean.name, c.ip); return { ok: true, message: 'Votre candidature a bien été reçue. Merci.' };
});
route('GET', '/api/public/survey/(\\d+)', false, async c => { const s = get("SELECT id,title,description,schema FROM surveys WHERE id=? AND is_public=1 AND status='open'", Number(c.m[1])); if (!s) throw nf('Enquête indisponible.'); return { id: s.id, title: s.title, description: s.description, schema: J(s.schema) }; });
route('POST', '/api/public/survey/(\\d+)', false, async c => {
  if (!A.rate('sv:' + c.ip, 30, 3600e3)) throw new HttpError(429, 'Trop de réponses depuis cette adresse.');
  const s = get("SELECT * FROM surveys WHERE id=? AND is_public=1 AND status='open'", Number(c.m[1])); if (!s) throw nf('Enquête indisponible.'); return submitSurvey(s, c.body.answers, null, c.ip);
});
function submitSurvey(s, ans, uid, ip) {
  const sc = J(s.schema) || { questions: [] }; const out = {}; ans = ans || {};
  for (const q of sc.questions) { let v = ans[q.id]; if (q.type === 'multi') v = Array.isArray(v) ? v.map(x => str(x, 200)).slice(0, 30) : []; else v = str(v, 2000); if (q.required && (Array.isArray(v) ? !v.length : !String(v).trim())) throw bad('Réponse obligatoire : ' + q.label); out[q.id] = v; }
  run('INSERT INTO survey_responses(survey_id,data,user_id,at,ip) VALUES(?,?,?,?,?)', s.id, JSON.stringify(out), uid, now(), ip); return { ok: true, message: 'Merci, votre réponse est enregistrée.' };
}

// ---- compte
function me(u) {
  const params_ = params(); const tools = FORMS.catalogue.filter(t => R.canCreate(u, t.code)).map(t => t.code);
  return { user: A.publicUser(u), role_label: roleLabel(u.role), tools, can_view_all: R.canViewAll(u), view_depts: R.viewDepts(u), params: params_,
    counts: { todo: get("SELECT COUNT(*) c FROM approvals WHERE assignee_id=? AND status='pending'", u.id).c, tasks: get("SELECT COUNT(*) c FROM tasks WHERE assignee_id=? AND status!='done'", u.id).c, notif: get('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND read=0', u.id).c, pending_users: u.role === 'ADMIN' ? get("SELECT COUNT(*) c FROM users WHERE status='pending'").c : 0 }, roles: Object.fromEntries(Object.entries(R.ROLES).map(([k, v]) => [k, v.label])), depts: DEPTS };
}
route('GET', '/api/me', true, async c => me(c.user));
route('POST', '/api/password', true, async c => {
  const u = c.user; if (!A.checkPwd(String(c.body.current || ''), u.salt, u.hash)) throw bad('Mot de passe actuel incorrect.');
  const pe = A.pwdPolicy(c.body.password, u.username); if (pe) throw bad(pe); const h = A.hashPwd(c.body.password);
  run('UPDATE users SET salt=?, hash=?, must_change=0 WHERE id=?', h.salt, h.hash, u.id); audit(u, 'password_change', u.username, '', c.ip);
  run('DELETE FROM sessions WHERE user_id=? AND sid!=?', u.id, A.sha(c.sid)); return { ok: true };
});
route('PUT', '/api/profile', true, async c => { run('UPDATE users SET email=?, phone=? WHERE id=?', str(c.body.email, 120), str(c.body.phone, 40), c.user.id); return { ok: true }; });

// ---- catalogue & circuits
route('GET', '/api/catalogue', true, async c => FORMS.catalogue.map(t => ({ ...t, allowed: R.canCreate(c.user, t.code) })));
route('GET', '/api/forms/(OUT-[A-Z]+-\\d+)', true, async c => { const f = FORMS.forms[c.m[1]]; if (!f) throw nf(); return f; });
route('POST', '/api/chain', true, async c => {
  const f = FORMS.forms[c.body.code]; if (!f) throw nf(); const ch = R.buildChain(f, c.body.amount, params());
  return { steps: ch.steps.map(s => ({ ...s, role_label: roleLabel(s.role), candidates: candidates(s.role, c.user.id) })), ext: ch.ext };
});

// ---- documents
function listDocs(u, q) {
  const v = visibleDocsSQL(u); let w = []; let p = [];
  const scope = q.scope || 'mine';
  if (scope === 'mine') { w.push('d.author_id=?'); p.push(u.id); }
  else if (scope === 'todo') { w.push("d.id IN (SELECT doc_id FROM approvals WHERE assignee_id=? AND status='pending')"); p.push(u.id); }
  else if (scope === 'signed') { w.push("d.id IN (SELECT doc_id FROM approvals WHERE assignee_id=? AND status IN ('approved','rejected'))"); p.push(u.id); }
  else { w.push(v.where); p.push(...v.p); }
  if (q.status) { w.push('d.status=?'); p.push(q.status); } if (q.dept && DEPTS[q.dept]) { w.push('d.dept=?'); p.push(q.dept); } if (q.code) { w.push('d.code=?'); p.push(q.code); }
  if (q.q) { w.push("(d.title LIKE ? OR d.ref LIKE ? OR d.project LIKE ?)"); const l = '%' + q.q.replace(/[%_]/g, '') + '%'; p.push(l, l, l); }
  return all(`SELECT d.id,d.ref,d.code,d.dept,d.title,d.status,d.amount,d.version,d.project,d.created_at,d.updated_at,d.author_id,u.name author FROM docs d JOIN users u ON u.id=d.author_id WHERE ${w.join(' AND ')} ORDER BY d.updated_at DESC LIMIT 300`, ...p).map(r => ({ ...r, tool: (FORMS.forms[r.code] || {}).title }));
}
route('GET', '/api/docs', true, async c => listDocs(c.user, c.query));
route('POST', '/api/docs', true, async c => {
  const b = c.body; const f = FORMS.forms[b.code]; if (!f) throw bad('Outil inconnu.'); if (!R.canCreate(c.user, b.code)) throw forbid('Votre rôle ne permet pas d’utiliser cet outil.');
  const ref = makeRef(b.code); const t = now();
  const r = run('INSERT INTO docs(ref,code,dept,title,author_id,status,data,amount,project,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)', ref, b.code, f.dept, str(b.title, 200), c.user.id, 'draft', JSON.stringify(cleanData(b.data)), Math.max(0, Number(b.amount) || 0), str(b.project, 120), t, t);
  audit(c.user, 'doc_create', ref, b.code, c.ip); return { id: Number(r.lastInsertRowid), ref };
});
function docView(u, d) {
  const x = ctxFor(d); const ap = loadApprovals(d.id); const pend = ap.find(a => a.status === 'pending');
  const editable = (d.author_id === u.id && ['draft', 'rejected'].includes(d.status)) || u.role === 'ADMIN';
  const reopen = d.author_id === u.id && ['approved', 'review'].includes(d.status);
  const att = all('SELECT id,name,mime,size,at FROM attachments WHERE doc_id=? ORDER BY id', d.id);
  const versions = all('SELECT v.version,v.at,v.reason,u.name by_name FROM doc_versions v LEFT JOIN users u ON u.id=v.by_user WHERE v.doc_id=? ORDER BY v.id DESC', d.id);
  return { doc: { ...d, data: x.data }, form: x.form, author: x.author, approvals: ap.map(a => ({ ...a, role_label: roleLabel(a.role), signature: a.step === 0 || a.status === 'approved' ? a.signature : null })), attachments: att, versions,
    can: { edit: editable, reopen, delete: d.author_id === u.id && d.status === 'draft' && d.version === 1 || u.role === 'ADMIN' && d.status === 'draft', submit: d.author_id === u.id && ['draft', 'rejected'].includes(d.status), decide: pend && pend.assignee_id === u.id ? pend.id : null, admin: u.role === 'ADMIN' } };
}
route('GET', '/api/docs/(\\d+)', true, async c => { const d = docRow(c.m[1]); if (!canSee(c.user, d)) throw forbid(); return docView(c.user, d); });
route('PUT', '/api/docs/(\\d+)', true, async c => {
  const d = docRow(c.m[1]); const u = c.user; const b = c.body; const isAuthor = d.author_id === u.id, isAdmin = u.role === 'ADMIN';
  if (!isAuthor && !isAdmin) throw forbid(); const open = ['draft', 'rejected'].includes(d.status);
  if (!open && !str(b.reason).trim()) throw bad('Un motif de correction est obligatoire pour modifier un document déjà soumis ou validé.');
  if (!open && !isAuthor && !isAdmin) throw forbid();
  tx(() => {
    const t = now(); let status = d.status, ver = d.version;
    if (!open) { snapshot(d, u.id, 'Avant correction : ' + str(b.reason, 300)); ver = d.version + 1;
      if (!isAdmin) { status = 'draft'; run("UPDATE approvals SET status='cancelled' WHERE doc_id=? AND status IN ('pending','waiting')", d.id); const p = loadApprovals(d.id).find(a => a.status === 'pending'); }
      else { /* correction administrative en place : le circuit de validation est conservé et la correction est tracée */ } }
    run('UPDATE docs SET title=?, data=?, amount=?, project=?, status=?, version=?, updated_at=? WHERE id=?', str(b.title ?? d.title, 200), JSON.stringify(cleanData(b.data)), Math.max(0, Number(b.amount) || 0), str(b.project ?? d.project, 120), status, ver, t, d.id);
    if (!open) snapshot({ ...d, version: ver, data: JSON.stringify(b.data), title: b.title, amount: b.amount }, u.id, 'Correction : ' + str(b.reason, 300));
    audit(u, open ? 'doc_edit' : 'doc_correct', d.ref, str(b.reason, 300), c.ip);
    if (!open) all('SELECT DISTINCT assignee_id FROM approvals WHERE doc_id=? AND step>0', d.id).forEach(a => notify(a.assignee_id, `Le document ${d.ref} a été corrigé (${str(b.reason, 80)})`, '#/doc/' + d.id));
  });
  return { ok: true };
});
route('DELETE', '/api/docs/(\\d+)', true, async c => {
  const d = docRow(c.m[1]); if (!((d.author_id === c.user.id || c.user.role === 'ADMIN') && d.status === 'draft')) throw forbid('Seul un brouillon peut être supprimé.');
  tx(() => { all('SELECT file FROM attachments WHERE doc_id=?', d.id).forEach(a => { try { fs.unlinkSync(path.join(UP, a.file)); } catch (e) {} }); run('DELETE FROM attachments WHERE doc_id=?', d.id); run('DELETE FROM approvals WHERE doc_id=?', d.id); run('DELETE FROM doc_versions WHERE doc_id=?', d.id); run('DELETE FROM docs WHERE id=?', d.id); });
  audit(c.user, 'doc_delete', d.ref, '', c.ip); return { ok: true };
});
route('POST', '/api/docs/(\\d+)/submit', true, async c => {
  const d = docRow(c.m[1]); const u = c.user; if (d.author_id !== u.id) throw forbid(); if (!['draft', 'rejected'].includes(d.status)) throw bad('Ce document est déjà soumis.');
  const f = FORMS.forms[d.code]; const chain = R.buildChain(f, d.amount, params()); const sig = validSig(c.body.signature); if (!sig) throw bad('Votre signature est requise pour soumettre le document.');
  if (!A.checkPwd(String(c.body.password || ''), u.salt, u.hash)) throw bad('Confirmez votre mot de passe pour signer.');
  const asg = c.body.approvers || {}; const chosen = [];
  for (const s of chain.steps) { const id = Number(asg[s.step]); if (!id) throw bad(`Choisissez la personne qui validera : ${s.label}.`); const cand = candidates(s.role, u.id).find(x => x.id === id); if (!cand) throw bad(`La personne choisie ne peut pas valider l’étape « ${s.label} ».`); chosen.push({ ...s, uid: id }); }
  tx(() => {
    const rd = currentRound(d.id) + 1; const t = now(); const dd = { ...d, version: d.version + (d.submitted_at ? 1 : 0) }; if (d.submitted_at) { run('UPDATE docs SET version=? WHERE id=?', dd.version, d.id); }
    run("INSERT INTO approvals(doc_id,round,step,role,label,assignee_id,status,signature,sig_hash,signed_at,signer_name) VALUES(?,?,0,'AUTHOR','Établi par',?,'approved',?,?,?,?)", d.id, rd, u.id, sig, sigHash(dd, u.id, t), t, u.name);
    chosen.forEach((s, i) => run('INSERT INTO approvals(doc_id,round,step,role,label,assignee_id,status,doa) VALUES(?,?,?,?,?,?,?,?)', d.id, rd, s.step, s.role, s.label, s.uid, i === 0 ? 'pending' : 'waiting', s.doa ? 1 : 0));
    run("UPDATE docs SET status='review', current_step=1, submitted_at=?, updated_at=? WHERE id=?", t, t, d.id); snapshot({ ...dd, data: d.data }, u.id, 'Soumission pour validation');
    notify(chosen[0].uid, `À valider : ${d.ref} – ${d.title || f.title} (de ${u.name})`, '#/doc/' + d.id);
  });
  audit(u, 'doc_submit', d.ref, '', c.ip); return { ok: true };
});
route('POST', '/api/docs/(\\d+)/decide', true, async c => {
  const d = docRow(c.m[1]); const u = c.user; const ap = loadApprovals(d.id); const cur = ap.find(a => a.status === 'pending');
  if (!cur || cur.assignee_id !== u.id) throw forbid('Ce document n’attend pas votre validation.');
  if (!A.checkPwd(String(c.body.password || ''), u.salt, u.hash)) throw bad('Confirmez votre mot de passe pour signer.');
  const act = c.body.action; const comment = str(c.body.comment, 800); const t = now();
  if (act === 'approve') {
    const sig = validSig(c.body.signature); if (!sig) throw bad('Signature requise.');
    tx(() => {
      run("UPDATE approvals SET status='approved', signature=?, sig_hash=?, signed_at=?, signer_name=?, comment=? WHERE id=?", sig, sigHash(d, u.id, t), t, u.name, comment, cur.id);
      const next = ap.find(a => a.step === cur.step + 1);
      if (next) { run("UPDATE approvals SET status='pending' WHERE id=?", next.id); run('UPDATE docs SET current_step=?, updated_at=? WHERE id=?', next.step, t, d.id); notify(next.assignee_id, `À valider : ${d.ref} – ${d.title || ''}`, '#/doc/' + d.id); }
      else { run("UPDATE docs SET status='approved', closed_at=?, updated_at=? WHERE id=?", t, t, d.id); notify(d.author_id, `Document validé : ${d.ref}`, '#/doc/' + d.id); }
    }); audit(u, 'doc_approve', d.ref, comment, c.ip);
  } else if (act === 'reject') {
    if (!comment.trim()) throw bad('Indiquez le motif du retour.');
    tx(() => { run("UPDATE approvals SET status='rejected', signed_at=?, signer_name=?, comment=? WHERE id=?", t, u.name, comment, cur.id); run("UPDATE approvals SET status='cancelled' WHERE doc_id=? AND round=? AND status='waiting'", d.id, cur.round); run("UPDATE docs SET status='rejected', updated_at=? WHERE id=?", t, d.id); notify(d.author_id, `Document retourné pour correction : ${d.ref} – ${comment.slice(0, 100)}`, '#/doc/' + d.id); }); audit(u, 'doc_reject', d.ref, comment, c.ip);
  } else throw bad('Action inconnue.');
  return { ok: true };
});
route('POST', '/api/docs/(\\d+)/archive', true, async c => { const d = docRow(c.m[1]); if (!(c.user.role === 'ADMIN' || d.author_id === c.user.id) || d.status !== 'approved') throw forbid('Seul un document validé peut être archivé.'); run("UPDATE docs SET status='archived', updated_at=? WHERE id=?", now(), d.id); audit(c.user, 'doc_archive', d.ref, '', c.ip); return { ok: true }; });
route('POST', '/api/docs/(\\d+)/attach', true, async c => {
  const d = docRow(c.m[1]); if (!canSee(c.user, d)) throw forbid(); if (!(d.author_id === c.user.id && ['draft', 'rejected'].includes(d.status) || c.user.role === 'ADMIN')) throw forbid('Pièces jointes modifiables uniquement en brouillon.');
  if (get('SELECT COUNT(*) c FROM attachments WHERE doc_id=?', d.id).c >= 20) throw bad('20 pièces jointes maximum.');
  const name = str(c.body.name, 150).replace(/[\\/]/g, '_'); const s = saveFile(name, c.body.data);
  const r = run('INSERT INTO attachments(doc_id,name,mime,size,file,by_user,at) VALUES(?,?,?,?,?,?,?)', d.id, name, str(c.body.mime, 100), s.size, s.file, c.user.id, now()); audit(c.user, 'attach', d.ref, name, c.ip); return { id: Number(r.lastInsertRowid) };
});
route('GET', '/api/files/(\\d+)', true, async c => {
  const a = get('SELECT * FROM attachments WHERE id=?', Number(c.m[1])); if (!a) throw nf(); const d = docRow(a.doc_id); if (!canSee(c.user, d)) throw forbid();
  const b = fs.readFileSync(path.join(UP, a.file)); const ext = a.name.split('.').pop().toLowerCase(); return { __raw: true, buf: b, type: MIME[ext] || OFFICE[ext] || 'application/octet-stream', name: a.name };
});
route('DELETE', '/api/files/(\\d+)', true, async c => { const a = get('SELECT * FROM attachments WHERE id=?', Number(c.m[1])); if (!a) throw nf(); const d = docRow(a.doc_id); if (!(d.author_id === c.user.id && ['draft', 'rejected'].includes(d.status) || c.user.role === 'ADMIN')) throw forbid(); try { fs.unlinkSync(path.join(UP, a.file)); } catch (e) {} run('DELETE FROM attachments WHERE id=?', a.id); return { ok: true }; });
route('GET', '/api/docs/(\\d+)/export', true, async c => {
  const d = docRow(c.m[1]); if (!canSee(c.user, d)) throw forbid(); const x = ctxFor(d); const fmt = c.query.fmt || 'docx'; const base = d.ref.replace(/\//g, '-'); audit(c.user, 'doc_export', d.ref, fmt, c.ip);
  if (fmt === 'docx') return { __raw: true, buf: await X.docToDocx(x), type: OFFICE.docx, name: base + '.docx' };
  if (fmt === 'xlsx') return { __raw: true, buf: await X.docToXlsx(x), type: OFFICE.xlsx, name: base + '.xlsx' };
  if (fmt === 'pptx') return { __raw: true, buf: await X.docToPptx(x), type: OFFICE.pptx, name: base + '.pptx' };
  if (fmt === 'json') return { __raw: true, buf: Buffer.from(JSON.stringify({ ref: d.ref, code: d.code, title: d.title, status: d.status, data: x.data, approvals: x.approvals.map(a => ({ role: a.role, signer: a.signer_name, at: a.signed_at, status: a.status, hash: a.sig_hash })) }, null, 1)), type: MIME.json, name: base + '.json' };
  throw bad('Format inconnu.');
});
route('GET', '/api/dashboard', true, async c => {
  const u = c.user; const v = visibleDocsSQL(u); const by = all(`SELECT d.status s, COUNT(*) n FROM docs d WHERE ${v.where} GROUP BY d.status`, ...v.p); const byDept = all(`SELECT d.dept s, COUNT(*) n FROM docs d WHERE ${v.where} GROUP BY d.dept`, ...v.p);
  const late = all("SELECT d.id,d.ref,d.title,a.label,u.name assignee FROM approvals a JOIN docs d ON d.id=a.doc_id LEFT JOIN users u ON u.id=a.assignee_id WHERE a.status='pending' AND d.updated_at<? AND (a.assignee_id=? OR ?=1) ORDER BY d.updated_at LIMIT 10", now() - 3 * 86400e3, u.id, R.canViewAll(u) ? 1 : 0);
  return { by_status: Object.fromEntries(by.map(r => [r.s, r.n])), by_dept: Object.fromEntries(byDept.map(r => [r.s, r.n])), todo: listDocs(u, { scope: 'todo' }).slice(0, 8), mine: listDocs(u, { scope: 'mine' }).slice(0, 6), late,
    tasks: all("SELECT t.*, c.name cname FROM tasks t LEFT JOIN users c ON c.id=t.created_by WHERE t.assignee_id=? AND t.status!='done' ORDER BY t.due IS NULL, t.due LIMIT 8", u.id), responsibilities: u.responsibilities || '' };
});

// ---- tâches et responsabilités
const CAN_ASSIGN = ['ADMIN', 'DE', 'COORD', 'PRES', 'ADM', 'RH', 'FIN', 'CPT', 'LOG', 'SEC', 'PROJ', 'RESP', 'MEAL'];
route('GET', '/api/users/lite', true, async () => all("SELECT id,name,post,role,dept FROM users WHERE status='active' ORDER BY name"));
route('GET', '/api/tasks', true, async c => {
  const s = c.query.scope || 'mine'; const mgr = isMgr(c.user);
  const w = s === 'all' && mgr ? '1=1' : s === 'assigned' ? 't.created_by=?' : 't.assignee_id=?'; const p = (s === 'all' && mgr) ? [] : [c.user.id];
  return all(`SELECT t.*, a.name aname, c.name cname, d.ref doc_ref FROM tasks t LEFT JOIN users a ON a.id=t.assignee_id LEFT JOIN users c ON c.id=t.created_by LEFT JOIN docs d ON d.id=t.doc_id WHERE ${w} ORDER BY (t.status='done'), t.due IS NULL, t.due LIMIT 300`, ...p);
});
route('POST', '/api/tasks', true, async c => {
  if (!CAN_ASSIGN.includes(c.user.role)) throw forbid('Votre rôle ne permet pas d’assigner des tâches.'); const b = c.body; if (!str(b.title).trim()) throw bad('Intitulé requis.');
  const a = get("SELECT * FROM users WHERE id=? AND status='active'", Number(b.assignee_id)); if (!a) throw bad('Personne assignée invalide.');
  const r = run('INSERT INTO tasks(title,description,assignee_id,created_by,due,procedure_ref,doc_id,created_at) VALUES(?,?,?,?,?,?,?,?)', str(b.title, 200), str(b.description, 2000), a.id, c.user.id, str(b.due, 10) || null, str(b.procedure_ref, 120), b.doc_id ? Number(b.doc_id) : null, now());
  notify(a.id, `Nouvelle tâche de ${c.user.name} : ${str(b.title, 80)}`, '#/taches'); audit(c.user, 'task_create', r.lastInsertRowid, b.title, c.ip); return { id: Number(r.lastInsertRowid) };
});
route('PUT', '/api/tasks/(\\d+)', true, async c => {
  const t = get('SELECT * FROM tasks WHERE id=?', Number(c.m[1])); if (!t) throw nf(); if (!(t.assignee_id === c.user.id || t.created_by === c.user.id || c.user.role === 'ADMIN')) throw forbid();
  const st = c.body.status === 'done' ? 'done' : 'open'; run('UPDATE tasks SET status=?, done_at=? WHERE id=?', st, st === 'done' ? now() : null, t.id); if (st === 'done') notify(t.created_by, `Tâche terminée : ${t.title} (${c.user.name})`, '#/taches'); return { ok: true };
});
route('DELETE', '/api/tasks/(\\d+)', true, async c => { const t = get('SELECT * FROM tasks WHERE id=?', Number(c.m[1])); if (!t) throw nf(); if (!(t.created_by === c.user.id || c.user.role === 'ADMIN')) throw forbid(); run('DELETE FROM tasks WHERE id=?', t.id); return { ok: true }; });

// ---- notifications
route('GET', '/api/notifications', true, async c => all('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 40', c.user.id));
route('POST', '/api/notifications/read', true, async c => { run('UPDATE notifications SET read=1 WHERE user_id=?', c.user.id); return { ok: true }; });

// ---- bibliothèque des procédures
route('GET', '/api/library', true, async () => ({ toc: TOC }));
route('GET', '/api/manual.pdf', true, async () => ({ __raw: true, inline: true, buf: fs.readFileSync(path.join(__dirname, 'assets', 'manuel.pdf')), type: MIME.pdf, name: 'Manuel_procedures_RFAD.pdf' }));
route('GET', '/api/templates', true, async () => Object.entries(X.TEMPLATES).map(([k, v]) => ({ key: k, ...v })));
route('GET', '/api/templates/([a-z]+)', true, async c => { const T = X.TEMPLATES[c.m[1]]; if (!T) throw nf(); return { __raw: true, buf: await X.template(c.m[1]), type: OFFICE[T.kind], name: `RFAD_${c.m[1]}.${T.kind}` }; });

// ---- enquêtes
const SURVEY_ROLES = ['ADMIN', 'DE', 'COORD', 'MEAL', 'RH', 'PROJ', 'ADM'];
route('GET', '/api/surveys', true, async c => all('SELECT s.*, (SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id=s.id) n FROM surveys s ORDER BY s.id DESC').map(s => ({ ...s, schema: J(s.schema) })));
function checkSchema(sc) { if (!sc || !Array.isArray(sc.questions) || !sc.questions.length || sc.questions.length > 80) throw bad('Ajoutez entre 1 et 80 questions.'); return { questions: sc.questions.map((q, i) => ({ id: 'q' + (i + 1), type: ['text', 'textarea', 'choice', 'multi', 'number', 'date', 'scale'].includes(q.type) ? q.type : 'text', label: str(q.label, 300) || 'Question ' + (i + 1), options: Array.isArray(q.options) ? q.options.map(o => str(o, 120)).filter(Boolean).slice(0, 30) : [], required: !!q.required })) }; }
route('POST', '/api/surveys', true, async c => { if (!SURVEY_ROLES.includes(c.user.role)) throw forbid(); const b = c.body; if (!str(b.title).trim()) throw bad('Titre requis.'); const r = run('INSERT INTO surveys(title,description,schema,is_public,created_by,created_at) VALUES(?,?,?,?,?,?)', str(b.title, 200), str(b.description, 1000), JSON.stringify(checkSchema(b.schema)), b.is_public ? 1 : 0, c.user.id, now()); audit(c.user, 'survey_create', r.lastInsertRowid, b.title, c.ip); return { id: Number(r.lastInsertRowid) }; });
route('PUT', '/api/surveys/(\\d+)', true, async c => { if (!SURVEY_ROLES.includes(c.user.role)) throw forbid(); const s = get('SELECT * FROM surveys WHERE id=?', Number(c.m[1])); if (!s) throw nf(); const b = c.body; const n = get('SELECT COUNT(*) c FROM survey_responses WHERE survey_id=?', s.id).c;
  run('UPDATE surveys SET title=?, description=?, schema=?, is_public=?, status=? WHERE id=?', str(b.title ?? s.title, 200), str(b.description ?? s.description, 1000), b.schema && !n ? JSON.stringify(checkSchema(b.schema)) : s.schema, b.is_public ? 1 : 0, b.status === 'closed' ? 'closed' : 'open', s.id); return { ok: true }; });
route('POST', '/api/surveys/(\\d+)/respond', true, async c => { const s = get("SELECT * FROM surveys WHERE id=? AND status='open'", Number(c.m[1])); if (!s) throw nf('Enquête clôturée.'); return submitSurvey(s, c.body.answers, c.user.id, c.ip); });

// ---- recrutement
const HR_ROLES = ['ADMIN', 'DE', 'COORD', 'RH'];
route('GET', '/api/jobs', true, async c => { if (!HR_ROLES.includes(c.user.role)) throw forbid(); return all('SELECT j.*, (SELECT COUNT(*) FROM applications a WHERE a.job_id=j.id) n FROM jobs j ORDER BY j.id DESC'); });
route('POST', '/api/jobs', true, async c => { if (!['ADMIN', 'RH', 'DE'].includes(c.user.role)) throw forbid(); const b = c.body; if (!str(b.title).trim()) throw bad('Intitulé du poste requis.'); const y = new Date().getFullYear(); const n = get('SELECT COUNT(*) c FROM jobs').c + 1;
  const r = run('INSERT INTO jobs(ref,title,dept,location,contract,description,profile,deadline,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)', `RFAD/RH/${y}/${String(n).padStart(3, '0')}`, str(b.title, 150), str(b.dept, 60), str(b.location, 100), str(b.contract, 60), str(b.description, 5000), str(b.profile, 3000), str(b.deadline, 10), c.user.id, now()); audit(c.user, 'job_create', b.title, '', c.ip); return { id: Number(r.lastInsertRowid) }; });
route('PUT', '/api/jobs/(\\d+)', true, async c => { if (!['ADMIN', 'RH', 'DE'].includes(c.user.role)) throw forbid(); const j = get('SELECT * FROM jobs WHERE id=?', Number(c.m[1])); if (!j) throw nf(); const b = c.body; run('UPDATE jobs SET title=?,dept=?,location=?,contract=?,description=?,profile=?,deadline=?,status=? WHERE id=?', str(b.title ?? j.title, 150), str(b.dept ?? j.dept, 60), str(b.location ?? j.location, 100), str(b.contract ?? j.contract, 60), str(b.description ?? j.description, 5000), str(b.profile ?? j.profile, 3000), str(b.deadline ?? j.deadline, 10), b.status === 'closed' ? 'closed' : 'open', j.id); return { ok: true }; });
route('GET', '/api/applications', true, async c => { if (!HR_ROLES.includes(c.user.role)) throw forbid(); const jid = Number(c.query.job_id) || null; return all(`SELECT a.*, j.title jt, j.ref jr FROM applications a LEFT JOIN jobs j ON j.id=a.job_id ${jid ? 'WHERE a.job_id=?' : ''} ORDER BY a.at DESC LIMIT 500`, ...(jid ? [jid] : [])).map(a => ({ ...a, data: J(a.data) })); });
route('PUT', '/api/applications/(\\d+)', true, async c => { if (!HR_ROLES.includes(c.user.role)) throw forbid(); const a = get('SELECT * FROM applications WHERE id=?', Number(c.m[1])); if (!a) throw nf(); const st = Object.keys(APP_ST).includes(c.body.status) ? c.body.status : a.status; run('UPDATE applications SET status=?, score=?, notes=? WHERE id=?', st, c.body.score === '' || c.body.score == null ? null : Number(c.body.score), str(c.body.notes, 2000), a.id); audit(c.user, 'application_update', a.id, st, c.ip); return { ok: true }; });
route('GET', '/api/applications/(\\d+)/file/(\\d)', true, async c => { if (!HR_ROLES.includes(c.user.role)) throw forbid(); const a = get('SELECT * FROM applications WHERE id=?', Number(c.m[1])); if (!a) throw nf(); const f = ((J(a.data) || {}).files || [])[Number(c.m[2])]; if (!f) throw nf(); const ext = f.name.split('.').pop().toLowerCase(); return { __raw: true, buf: fs.readFileSync(path.join(UP, f.file)), type: MIME[ext] || OFFICE[ext] || 'application/octet-stream', name: f.name }; });

// ---- rapports
route('GET', '/api/report', true, async c => ({ __table: true, t: reportTable(c.user, c.query), fmt: c.query.fmt || 'json' }));

// ---- administration
const ADMIN = c => { if (c.user.role !== 'ADMIN') throw forbid('Réservé à l’administrateur.'); };
route('GET', '/api/admin/users', true, async c => { ADMIN(c); return all('SELECT id,username,name,email,phone,role,dept,post,responsibilities,extra_tools,status,requested_post,message,created_at,last_login,must_change FROM users ORDER BY (status=\'pending\') DESC, name'); });
route('PUT', '/api/admin/users/(\\d+)', true, async c => {
  ADMIN(c); const u = get('SELECT * FROM users WHERE id=?', Number(c.m[1])); if (!u) throw nf(); const b = c.body;
  const role = R.ROLES[b.role] ? b.role : u.role; const status = ['active', 'pending', 'rejected', 'suspended'].includes(b.status) ? b.status : u.status;
  if (u.id === c.user.id && (role !== 'ADMIN' || status !== 'active')) throw bad('Vous ne pouvez pas retirer vos propres droits d’administrateur.');
  if (u.role === 'ADMIN' && (role !== 'ADMIN' || status !== 'active') && get("SELECT COUNT(*) c FROM users WHERE role='ADMIN' AND status='active'").c < 2) throw bad('Il doit rester au moins un administrateur actif.');
  const extra = Array.isArray(b.extra_tools) ? b.extra_tools.filter(x => /^[A-Z]+-\d+$/.test(x)).slice(0, 100) : J(u.extra_tools) || [];
  run('UPDATE users SET role=?, dept=?, post=?, responsibilities=?, extra_tools=?, status=?, approved_by=?, approved_at=? WHERE id=?', role, DEPTS[b.dept] ? b.dept : null, str(b.post, 120), str(b.responsibilities, 2000), JSON.stringify(extra), status, status === 'active' && u.status !== 'active' ? c.user.id : u.approved_by, status === 'active' && u.status !== 'active' ? now() : u.approved_at, u.id);
  if (status !== 'active') A.destroyUserSessions(u.id); if (status === 'active' && u.status === 'pending') { notify(u.id, 'Votre accès à RFAD Gestion a été validé. Rôle : ' + roleLabel(role), '#/'); M.queue(u.email, 'RFAD Gestion – votre accès est validé', `Bonjour ${u.name},\n\nVotre demande d’accès à RFAD Gestion a été validée par l’administrateur.\nNom d’utilisateur : ${u.username}\nRôle : ${roleLabel(role)}${str(b.post, 120) ? '\nPoste : ' + str(b.post, 120) : ''}\n\nConnectez-vous avec le mot de passe choisi lors de votre demande : ${(M.baseUrl() || '') || 'adresse du système communiquée par RFAD'}\n\nRFAD ASBL`); }
  if (status === 'rejected' && u.status === 'pending') M.queue(u.email, 'RFAD Gestion – demande d’accès', `Bonjour ${u.name},\n\nVotre demande d’accès à RFAD Gestion n’a pas été acceptée. Pour plus d’informations, contactez l’administrateur (${M.adminEmail()}).\n\nRFAD ASBL`);
  audit(c.user, 'user_update', u.username, `rôle=${role} statut=${status} poste=${str(b.post, 60)}`, c.ip); return { ok: true };
});
route('POST', '/api/admin/users', true, async c => { ADMIN(c); const b = c.body; const un = str(b.username, 30).toLowerCase().trim(); if (!/^[a-z0-9._-]{3,30}$/.test(un)) throw bad('Nom d’utilisateur invalide.'); if (get('SELECT 1 x FROM users WHERE username=?', un)) throw bad('Nom d’utilisateur déjà pris.');
  const pwd = crypto.randomBytes(7).toString('base64url') + 'k7'; const h = A.hashPwd(pwd); const role = R.ROLES[b.role] ? b.role : 'AGENT';
  run("INSERT INTO users(username,name,email,phone,salt,hash,role,dept,post,responsibilities,status,must_change,created_at,approved_by,approved_at) VALUES(?,?,?,?,?,?,?,?,?,?,'active',1,?,?,?)", un, str(b.name, 100), str(b.email, 120), str(b.phone, 40), h.salt, h.hash, role, DEPTS[b.dept] ? b.dept : null, str(b.post, 120), str(b.responsibilities, 2000), now(), c.user.id, now()); audit(c.user, 'user_create', un, role, c.ip); if (b.send_email && b.email) M.queue(b.email, 'RFAD Gestion – votre compte est créé', credMail(str(b.name, 100), un, pwd)); return { ok: true, temp_password: pwd }; });
const credMail = (name, un, pwd) => `Bonjour ${name},\n\nVotre compte RFAD Gestion a été créé par l’administrateur.\nAdresse : ${M.baseUrl() || 'communiquée par RFAD'}\nNom d’utilisateur : ${un}\nMot de passe temporaire : ${pwd}\n\nVous devrez changer ce mot de passe à votre première connexion. Ne le communiquez à personne.\n\nRFAD ASBL`;
route('POST', '/api/admin/users/bulk', true, async c => {
  ADMIN(c); const lines = String(c.body.text || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean).slice(0, 300); if (!lines.length) throw bad('Collez au moins une ligne : Nom ; E-mail ; Rôle ; Département ; Poste.');
  const roleBy = {}; Object.entries(R.ROLES).forEach(([k, v]) => { roleBy[k.toLowerCase()] = k; roleBy[v.label.toLowerCase()] = k; });
  const out = [];
  for (const ln of lines) {
    const [name, email, rl, dp, post] = ln.split(/[;\t]/).map(x => (x || '').trim()); if (!name || /^nom$/i.test(name)) continue;
    const role = roleBy[(rl || '').toLowerCase()] || 'AGENT'; const dept = DEPTS[(dp || '').toUpperCase()] ? dp.toUpperCase() : null;
    let base = name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, '').slice(0, 24) || 'user'; let un = base, i = 1; while (get('SELECT 1 x FROM users WHERE username=?', un)) un = base + (++i);
    const pwd = crypto.randomBytes(7).toString('base64url') + 'k7'; const h = A.hashPwd(pwd);
    run("INSERT INTO users(username,name,email,salt,hash,role,dept,post,status,must_change,created_at,approved_by,approved_at) VALUES(?,?,?,?,?,?,?,?,'active',1,?,?,?)", un, name.slice(0, 100), email.slice(0, 120), h.salt, h.hash, role, dept, post.slice(0, 120), now(), c.user.id, now());
    if (c.body.send_email && email) M.queue(email, 'RFAD Gestion – votre compte est créé', credMail(name, un, pwd));
    out.push({ name, username: un, email, role: roleLabel(role), temp_password: pwd });
  }
  audit(c.user, 'user_bulk', out.length + ' comptes', '', c.ip); return { created: out };
});
route('GET', '/api/admin/mail', true, async c => { ADMIN(c); const s = M.smtpConf(); return { configured: M.configured(), admin_email: M.adminEmail(), base_url: M.baseUrl(), host: s.host, port: s.port, secure: s.secure, user: s.user, from: s.from, has_pass: !!s.pass }; });
route('PUT', '/api/admin/mail', true, async c => { ADMIN(c); const b = c.body; const cur = setting('smtp', {}) || {};
  if (b.admin_email != null) { if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(b.admin_email)) throw bad('E-mail administrateur invalide.'); setSetting('admin_email', str(b.admin_email, 120)); }
  if (b.base_url != null) setSetting('base_url', str(b.base_url, 200).replace(/\/+$/, ''));
  setSetting('smtp', { host: str(b.host, 120), port: Number(b.port) || 465, secure: !!b.secure, user: str(b.user, 120), pass: b.pass ? str(b.pass, 200) : cur.pass || '', from: str(b.from, 160) });
  audit(c.user, 'mail_config', 'smtp', str(b.host, 60), c.ip); M.flush().catch(() => {}); return { ok: true }; });
route('POST', '/api/admin/mail/test', true, async c => { ADMIN(c); if (!M.configured()) throw bad('Renseignez d’abord le serveur SMTP.'); try { await M.test(M.adminEmail()); } catch (e) { throw bad('Échec d’envoi : ' + e.message); } return { ok: true, to: M.adminEmail() }; });
route('GET', '/api/admin/outbox', true, async c => { ADMIN(c); return all('SELECT id,to_addr,subject,status,tries,error,at,sent_at FROM outbox ORDER BY id DESC LIMIT 100'); });
route('POST', '/api/admin/outbox/retry', true, async c => { ADMIN(c); run("UPDATE outbox SET status='pending', tries=0 WHERE status='failed'"); M.flush().catch(() => {}); return { ok: true }; });
route('POST', '/api/admin/users/(\\d+)/reset', true, async c => { ADMIN(c); const u = get('SELECT * FROM users WHERE id=?', Number(c.m[1])); if (!u) throw nf(); const pwd = crypto.randomBytes(7).toString('base64url') + 'k7'; const h = A.hashPwd(pwd); run('UPDATE users SET salt=?, hash=?, must_change=1, failed=0, locked_until=0 WHERE id=?', h.salt, h.hash, u.id); A.destroyUserSessions(u.id); audit(c.user, 'password_reset', u.username, '', c.ip); return { temp_password: pwd }; });
route('GET', '/api/admin/audit', true, async c => { if (!['ADMIN', 'CC'].includes(c.user.role)) throw forbid(); return all('SELECT * FROM audit ORDER BY id DESC LIMIT 300'); });
route('GET', '/api/admin/params', true, async c => params());
route('PUT', '/api/admin/params', true, async c => { ADMIN(c); const p = c.body; if (!p || !Array.isArray(p.doa) || !Array.isArray(p.purchase)) throw bad('Paramètres invalides.'); setSetting('params', p); audit(c.user, 'params_update', 'params', '', c.ip); return { ok: true }; });
route('GET', '/api/admin/backup', true, async c => { ADMIN(c); const f = path.join(DB.DATA, 'backup_' + Date.now() + '.db'); DB.db.exec(`VACUUM INTO '${f.replace(/'/g, "''")}'`); const b = fs.readFileSync(f); fs.unlinkSync(f); audit(c.user, 'backup', 'db', '', c.ip); return { __raw: true, buf: b, type: 'application/octet-stream', name: 'rfad_sauvegarde_' + new Date().toISOString().slice(0, 10) + '.db' }; });

// ---------------------------------------------------------------- serveur
const server = http.createServer(async (req, res) => {
  const secure = TRUST ? req.headers['x-forwarded-proto'] === 'https' : false; secHeaders(res, secure);
  try {
    const url = new URL(req.url, 'http://x'); const p = decodeURIComponent(url.pathname);
    if (p.startsWith('/api/')) {
      const query = Object.fromEntries(url.searchParams); const cookies = parseCookies(req.headers.cookie); const ip = clientIp(req);
      if (!['GET', 'HEAD'].includes(req.method)) { // protection CSRF
        if (req.headers['x-rfad'] !== '1') throw forbid('Requête refusée.'); const o = req.headers.origin; if (o && new URL(o).host !== req.headers.host && !(TRUST && new URL(o).host === req.headers['x-forwarded-host'])) throw forbid('Origine refusée.'); }
      for (const r of routes) {
        if (r.m !== req.method) continue; const m = r.re.exec(p); if (!m) continue;
        const c = { req, res, m, query, ip, secure, sid: cookies.rfad_sid, user: null, body: {} };
        if (r.auth) { c.user = A.sessionUser(c.sid); if (!c.user) throw new HttpError(401, 'Session expirée. Veuillez vous reconnecter.'); if (c.user.must_change && !(p === '/api/password' || p === '/api/me' || p === '/api/logout')) throw new HttpError(403, 'Vous devez d’abord changer votre mot de passe.'); }
        if (['POST', 'PUT', 'DELETE'].includes(req.method)) c.body = await readBody(req);
        const out = await r.fn(c); if (c.setCookie) res.setHeader('Set-Cookie', c.setCookie);
        if (out && out.__raw) { res.writeHead(200, { 'Content-Type': out.type, 'Content-Length': out.buf.length, 'Content-Disposition': `${out.inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(out.name)}`, 'Cache-Control': 'no-store' }); return res.end(out.buf); }
        if (out && out.__table) return await sendTable(res, out.t, out.fmt, 'RFAD_rapport_' + new Date().toISOString().slice(0, 10));
        return json(res, 200, out);
      }
      throw nf('Service introuvable.');
    }
    // fichiers statiques
    let f = p === '/' ? '/index.html' : p; const full = path.normalize(path.join(PUBDIR, f)); if (!full.startsWith(PUBDIR)) throw forbid();
    if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) throw nf('Page introuvable.');
    const ext = path.extname(full).slice(1); const b = fs.readFileSync(full);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': b.length, 'Cache-Control': ['html', 'js', 'css'].includes(ext) || f === '/sw.js' ? 'no-cache' : 'public, max-age=86400' }); res.end(b);
  } catch (e) {
    if (!(e instanceof HttpError)) { console.error(e); e = new HttpError(500, 'Erreur interne du serveur.'); }
    if (!res.headersSent) json(res, e.code, { error: e.message }); else res.end();
  }
});
server.on('clientError', (e, s) => s.end('HTTP/1.1 400 Bad Request\r\n\r\n'));
if (require.main === module) server.listen(PORT, HOST, () => console.log(`RFAD Gestion – http://${HOST}:${PORT}  (données : ${DB.DATA})`));
module.exports = { server };
